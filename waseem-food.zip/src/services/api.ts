import { Product, Category, Deal, Order } from '../types';
import { PRODUCTS } from '../data/products';
import { CATEGORIES } from '../data/categories';
import { DEALS } from '../data/deals';

// Simulated delay helper for realistic asynchronous contract
const delay = (ms: number = 50) => new Promise((resolve) => setTimeout(resolve, ms));

/**
 * Clean API service layer.
 * In production with a Node.js/Express backend, these functions can simply call:
 *   const res = await fetch(`${API_BASE_URL}/products`);
 *   return res.json();
 */
export async function getProducts(): Promise<Product[]> {
  await delay(20);
  return [...PRODUCTS];
}

export async function getProductBySlug(slug: string): Promise<Product | null> {
  await delay(20);
  const found = PRODUCTS.find((p) => p.slug.toLowerCase() === slug.toLowerCase());
  return found ? { ...found } : null;
}

export async function getProductsByCategory(categoryName: string): Promise<Product[]> {
  await delay(20);
  if (!categoryName || categoryName.toLowerCase() === 'all') {
    return [...PRODUCTS];
  }
  return PRODUCTS.filter(
    (p) => p.category.toLowerCase() === categoryName.toLowerCase()
  );
}

export async function getPopularProducts(limit: number = 6): Promise<Product[]> {
  await delay(20);
  const featured = PRODUCTS.filter((p) => p.featured);
  return featured.slice(0, limit);
}

export async function getCategories(): Promise<Category[]> {
  await delay(10);
  return [...CATEGORIES];
}

export async function getDeals(): Promise<Deal[]> {
  await delay(20);
  return [...DEALS];
}

export async function getDealBySlug(slug: string): Promise<Deal | null> {
  await delay(20);
  const found = DEALS.find((d) => d.slug.toLowerCase() === slug.toLowerCase());
  return found ? { ...found } : null;
}

export async function searchProducts(query: string): Promise<Product[]> {
  await delay(20);
  const clean = query.trim().toLowerCase();
  if (!clean) return [];

  return PRODUCTS.filter((p) => {
    return (
      p.name.toLowerCase().includes(clean) ||
      p.category.toLowerCase().includes(clean) ||
      p.description.toLowerCase().includes(clean) ||
      (p.tags && p.tags.some((t) => t.toLowerCase().includes(clean)))
    );
  });
}

export async function createOrder(orderPayload: Omit<Order, 'orderId' | 'createdAt' | 'status'>): Promise<Order> {
  await delay(100);
  const randomNum = Math.floor(10000 + Math.random() * 90000);
  const orderId = `WF-${randomNum}`;

  const newOrder: Order = {
    ...orderPayload,
    orderId,
    createdAt: new Date().toISOString(),
    status: 'confirmed',
  };

  // Persist to localStorage for frontend demonstration
  try {
    const existing = JSON.parse(localStorage.getItem('wf_orders') || '[]');
    existing.unshift(newOrder);
    localStorage.setItem('wf_orders', JSON.stringify(existing));
    localStorage.setItem('wf_latest_order', JSON.stringify(newOrder));
  } catch (err) {
    console.error('Error saving order to localStorage:', err);
  }

  return newOrder;
}

export async function getLatestOrder(): Promise<Order | null> {
  try {
    const saved = localStorage.getItem('wf_latest_order');
    return saved ? JSON.parse(saved) : null;
  } catch {
    return null;
  }
}
