export interface Product {
  id: string | number;
  name: string;
  slug: string;
  category: string;
  description: string;
  price: number;
  oldPrice?: number;
  discount?: number; // percentage
  rating: number;
  reviewsCount?: number;
  image: string;
  featured?: boolean;
  available: boolean;
  spicyLevel?: 0 | 1 | 2 | 3;
  serves?: string;
  prepTime?: string;
  tags?: string[];
}

export interface Deal {
  id: string | number;
  name: string;
  slug: string;
  description: string;
  includedItems: string[];
  price: number;
  oldPrice: number;
  discount: number;
  image: string;
  badge?: string;
  serves?: string;
  available: boolean;
}

export interface Category {
  id: string;
  name: string;
  slug: string;
  iconName: string;
  description?: string;
  itemCount?: number;
}

export interface CartItem {
  id: string; // unique cart entry id (can be productId or dealId + notes)
  itemType: 'product' | 'deal';
  itemId: string | number;
  name: string;
  slug: string;
  price: number;
  oldPrice?: number;
  image: string;
  quantity: number;
  specialInstructions?: string;
}

export interface CustomerDetails {
  fullName: string;
  phone: string;
  email: string;
  address: string;
  city: string;
  area?: string;
  orderNotes?: string;
}

export type PaymentMethod = 'cod' | 'easypaisa' | 'jazzcash' | 'bank_transfer';

export interface Order {
  orderId: string;
  createdAt: string;
  items: CartItem[];
  subtotal: number;
  deliveryFee: number;
  discountAmount: number;
  total: number;
  customer: CustomerDetails;
  paymentMethod: PaymentMethod;
  status: 'pending' | 'confirmed' | 'preparing' | 'out_for_delivery' | 'delivered';
}

export interface RestaurantInfo {
  name: string;
  legalName: string;
  domain: string;
  tagline: string;
  subtitle: string;
  phone: string;
  displayPhone: string;
  whatsappNumber: string;
  whatsappDisplay: string;
  email: string;
  ordersEmail: string;
  address: string;
  city: string;
  coordinates: {
    lat: number;
    lng: number;
  };
  openingHours: string;
  currency: string;
  currencySymbol: string;
  standardDeliveryFee: number;
  freeDeliveryThreshold: number;
  socials: {
    facebook: string;
    instagram: string;
    tiktok: string;
    youtube: string;
  };
}
