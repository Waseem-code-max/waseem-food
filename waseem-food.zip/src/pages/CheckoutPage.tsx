import React, { useState, useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import {
  ShieldCheck,
  ShoppingBag,
  ArrowRight,
  CreditCard,
  Banknote,
  Smartphone,
  Building,
  Check,
  Tag,
  AlertCircle,
} from 'lucide-react';
import { Breadcrumb } from '../components/Breadcrumb';
import { useCart } from '../context/CartContext';
import { createOrder } from '../services/api';
import { PaymentMethod } from '../types';
import { RESTAURANT_INFO, CITIES_SERVED } from '../config/restaurant';

export const CheckoutPage: React.FC = () => {
  const { items, subtotal, deliveryFee, total, clearCart } = useCart();
  const navigate = useNavigate();

  const [formData, setFormData] = useState({
    fullName: '',
    phone: '',
    email: '',
    address: '',
    city: 'Lahore',
    orderNotes: '',
  });

  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('cod');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [formErrors, setFormErrors] = useState<Record<string, string>>({});

  useEffect(() => {
    window.scrollTo(0, 0);
    document.title = `Checkout | ${RESTAURANT_INFO.name}`;
  }, []);

  const validate = () => {
    const errors: Record<string, string> = {};
    if (!formData.fullName.trim()) errors.fullName = 'Please enter your full name';
    if (!formData.phone.trim()) errors.phone = 'Please enter a valid phone number (e.g. 0300-1234567)';
    if (!formData.email.trim() || !formData.email.includes('@')) errors.email = 'Please provide a valid email address';
    if (!formData.address.trim()) errors.address = 'Please specify your street address or house/apartment number';
    setFormErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handlePlaceOrder = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;
    if (items.length === 0) return;

    setIsSubmitting(true);

    try {
      const order = await createOrder({
        items,
        subtotal,
        deliveryFee,
        discountAmount: 0,
        total,
        customer: {
          fullName: formData.fullName,
          phone: formData.phone,
          email: formData.email,
          address: formData.address,
          city: formData.city,
          orderNotes: formData.orderNotes,
        },
        paymentMethod,
      });

      // Clear shopping cart and redirect to order success
      clearCart();
      navigate('/order-success');
    } catch (err) {
      console.error('Failed to create order:', err);
      setIsSubmitting(false);
    }
  };

  if (items.length === 0) {
    return (
      <div className="min-h-screen bg-[#FFF8EF] py-20 px-4">
        <div className="max-w-md mx-auto bg-white rounded-3xl p-8 text-center shadow-md border border-gray-100">
          <div className="w-16 h-16 rounded-full bg-[#FFF8EF] text-[#D62828] flex items-center justify-center mx-auto mb-4">
            <ShoppingBag className="w-8 h-8" />
          </div>
          <h2 className="text-xl font-black text-[#1F1F1F]">Your Cart is Empty</h2>
          <p className="text-xs sm:text-sm text-gray-500 mt-2">
            Please add at least one item or deal to your cart before proceeding to checkout.
          </p>
          <Link
            to="/menu"
            className="mt-6 inline-flex items-center gap-2 px-6 py-3 rounded-2xl bg-[#F77F00] text-white font-extrabold text-xs shadow-md"
          >
            <span>Explore Menu</span>
            <ArrowRight className="w-4 h-4" />
          </Link>
        </div>
      </div>
    );
  }

  const paymentOptions: { id: PaymentMethod; label: string; desc: string; icon: React.ComponentType<{ className?: string }> }[] = [
    {
      id: 'cod',
      label: 'Cash on Delivery (COD)',
      desc: 'Pay safely with cash when your food is delivered to your door.',
      icon: Banknote,
    },
    {
      id: 'easypaisa',
      label: 'Easypaisa Mobile Wallet',
      desc: 'Instant digital wallet payment via your Easypaisa account.',
      icon: Smartphone,
    },
    {
      id: 'jazzcash',
      label: 'JazzCash Wallet',
      desc: 'Pay directly using your JazzCash mobile account number.',
      icon: Smartphone,
    },
    {
      id: 'bank_transfer',
      label: 'Direct Bank Transfer / Raast',
      desc: 'Transfer via Raast ID or Pakistani bank mobile apps.',
      icon: Building,
    },
  ];

  // Reusable Order Summary Component
  const OrderSummaryBox = () => (
    <div className="bg-white rounded-3xl border border-gray-100 p-6 shadow-md">
      <div className="flex items-center justify-between pb-4 border-b border-gray-100">
        <h3 className="text-lg font-black text-[#1F1F1F]">Order Summary</h3>
        <span className="text-xs font-bold text-[#D62828] bg-[#FFECEC] px-2.5 py-1 rounded-full">
          {items.length} item{items.length !== 1 ? 's' : ''}
        </span>
      </div>

      {/* Item List */}
      <div className="divide-y divide-gray-50 max-h-64 overflow-y-auto my-3 pr-1">
        {items.map((item) => (
          <div key={item.id} className="py-3 flex items-center justify-between gap-3 text-xs">
            <div className="flex items-center gap-2.5 min-w-0">
              <img
                src={item.image}
                alt={item.name}
                className="w-10 h-10 rounded-lg object-cover shrink-0 border border-gray-100"
              />
              <div className="min-w-0">
                <span className="font-bold text-[#1F1F1F] truncate block">
                  {item.name}
                </span>
                <span className="text-gray-500 text-[11px]">
                  Qty: {item.quantity} × {RESTAURANT_INFO.currency} {item.price.toLocaleString()}
                </span>
              </div>
            </div>
            <span className="font-extrabold text-[#1F1F1F] shrink-0">
              {RESTAURANT_INFO.currency} {(item.price * item.quantity).toLocaleString()}
            </span>
          </div>
        ))}
      </div>

      {/* Subtotal, Delivery, Grand Total */}
      <div className="pt-3 border-t border-gray-100 space-y-2 text-xs text-gray-600">
        <div className="flex justify-between">
          <span>Subtotal</span>
          <span className="font-bold text-[#1F1F1F]">
            {RESTAURANT_INFO.currency} {subtotal.toLocaleString()}
          </span>
        </div>

        <div className="flex justify-between items-center">
          <span>Delivery Charges</span>
          <span className="font-bold text-[#1F1F1F]">
            {deliveryFee === 0 ? (
              <span className="text-[#2A9D8F] font-black">FREE Delivery</span>
            ) : (
              `${RESTAURANT_INFO.currency} ${deliveryFee.toLocaleString()}`
            )}
          </span>
        </div>

        <div className="pt-3 border-t border-gray-100 flex justify-between items-baseline text-sm">
          <span className="font-black text-[#1F1F1F]">Total Amount</span>
          <span className="text-2xl font-black text-[#D62828]">
            {RESTAURANT_INFO.currency} {total.toLocaleString()}
          </span>
        </div>
      </div>

      <div className="mt-4 p-3 rounded-xl bg-[#FFF8EF] border border-[#FCBF49]/30 flex items-center gap-2 text-[11px] text-gray-600">
        <Tag className="w-3.5 h-3.5 text-[#F77F00] shrink-0" />
        <span>No hidden service taxes. Guaranteed accurate billing.</span>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-[#FFF8EF] py-8 sm:py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Breadcrumb */}
        <Breadcrumb items={[{ label: 'Menu', to: '/menu' }, { label: 'Checkout' }]} />

        {/* Page Title */}
        <div className="mt-4 mb-8">
          <h1 className="text-3xl sm:text-4xl font-black text-[#1F1F1F] font-display tracking-tight">
            Checkout &amp; Delivery Details
          </h1>
          <p className="text-sm text-gray-600 mt-1">
            Please enter your delivery address and preferred payment method.
          </p>
        </div>

        <form onSubmit={handlePlaceOrder}>
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            
            {/* Left Column: Form Fields (7 cols) */}
            <div className="lg:col-span-7 space-y-6">
              
              {/* Step 1: Customer Contact Info */}
              <div className="bg-white rounded-3xl border border-gray-100 p-6 sm:p-8 shadow-sm">
                <div className="flex items-center gap-3 mb-6 pb-3 border-b border-gray-100">
                  <div className="w-8 h-8 rounded-full bg-[#D62828] text-white flex items-center justify-center font-black text-xs">
                    1
                  </div>
                  <h2 className="text-lg font-black text-[#1F1F1F]">
                    Customer Information
                  </h2>
                </div>

                <div className="space-y-4">
                  <div>
                    <label htmlFor="checkout-fullName" className="block text-xs font-bold text-gray-700 mb-1">
                      Full Name *
                    </label>
                    <input
                      type="text"
                      id="checkout-fullName"
                      value={formData.fullName}
                      onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                      placeholder="e.g. Asad Mehmood"
                      className={`w-full px-4 py-3 rounded-xl border text-sm focus:outline-none focus:ring-2 ${
                        formErrors.fullName
                          ? 'border-red-500 focus:ring-red-200'
                          : 'border-gray-200 focus:border-[#F77F00] focus:ring-[#F77F00]/20'
                      }`}
                    />
                    {formErrors.fullName && (
                      <p className="text-xs text-red-500 mt-1 flex items-center gap-1">
                        <AlertCircle className="w-3 h-3" /> {formErrors.fullName}
                      </p>
                    )}
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label htmlFor="checkout-phone" className="block text-xs font-bold text-gray-700 mb-1">
                        Phone Number * (for delivery rider)
                      </label>
                      <input
                        type="tel"
                        id="checkout-phone"
                        value={formData.phone}
                        onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                        placeholder="0300-1234567"
                        className={`w-full px-4 py-3 rounded-xl border text-sm focus:outline-none focus:ring-2 ${
                          formErrors.phone
                            ? 'border-red-500 focus:ring-red-200'
                            : 'border-gray-200 focus:border-[#F77F00] focus:ring-[#F77F00]/20'
                        }`}
                      />
                      {formErrors.phone && (
                        <p className="text-xs text-red-500 mt-1 flex items-center gap-1">
                          <AlertCircle className="w-3 h-3" /> {formErrors.phone}
                        </p>
                      )}
                    </div>

                    <div>
                      <label htmlFor="checkout-email" className="block text-xs font-bold text-gray-700 mb-1">
                        Email Address * (for receipt)
                      </label>
                      <input
                        type="email"
                        id="checkout-email"
                        value={formData.email}
                        onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                        placeholder="asad@example.com"
                        className={`w-full px-4 py-3 rounded-xl border text-sm focus:outline-none focus:ring-2 ${
                          formErrors.email
                            ? 'border-red-500 focus:ring-red-200'
                            : 'border-gray-200 focus:border-[#F77F00] focus:ring-[#F77F00]/20'
                        }`}
                      />
                      {formErrors.email && (
                        <p className="text-xs text-red-500 mt-1 flex items-center gap-1">
                          <AlertCircle className="w-3 h-3" /> {formErrors.email}
                        </p>
                      )}
                    </div>
                  </div>
                </div>
              </div>

              {/* Step 2: Delivery Address */}
              <div className="bg-white rounded-3xl border border-gray-100 p-6 sm:p-8 shadow-sm">
                <div className="flex items-center gap-3 mb-6 pb-3 border-b border-gray-100">
                  <div className="w-8 h-8 rounded-full bg-[#F77F00] text-white flex items-center justify-center font-black text-xs">
                    2
                  </div>
                  <h2 className="text-lg font-black text-[#1F1F1F]">
                    Delivery Address
                  </h2>
                </div>

                <div className="space-y-4">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label htmlFor="checkout-city" className="block text-xs font-bold text-gray-700 mb-1">
                        City *
                      </label>
                      <select
                        id="checkout-city"
                        value={formData.city}
                        onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                        className="w-full px-4 py-3 rounded-xl border border-gray-200 text-sm bg-white focus:outline-none focus:border-[#F77F00] font-medium"
                      >
                        {CITIES_SERVED.map((city) => (
                          <option key={city} value={city}>
                            {city}
                          </option>
                        ))}
                      </select>
                    </div>

                    <div>
                      <label htmlFor="checkout-area" className="block text-xs font-bold text-gray-700 mb-1">
                        Area / Sector / Phase
                      </label>
                      <input
                        type="text"
                        id="checkout-area"
                        placeholder="e.g. Gulberg, DHA, Bahria, F-10"
                        className="w-full px-4 py-3 rounded-xl border border-gray-200 text-sm focus:outline-none focus:border-[#F77F00]"
                      />
                    </div>
                  </div>

                  <div>
                    <label htmlFor="checkout-address" className="block text-xs font-bold text-gray-700 mb-1">
                      Street Address &amp; House / Flat No. *
                    </label>
                    <textarea
                      id="checkout-address"
                      rows={2}
                      value={formData.address}
                      onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                      placeholder="e.g. House #24, Street 7, Block B, near Main Commercial Market"
                      className={`w-full px-4 py-3 rounded-xl border text-sm focus:outline-none focus:ring-2 resize-none ${
                        formErrors.address
                          ? 'border-red-500 focus:ring-red-200'
                          : 'border-gray-200 focus:border-[#F77F00] focus:ring-[#F77F00]/20'
                      }`}
                    />
                    {formErrors.address && (
                      <p className="text-xs text-red-500 mt-1 flex items-center gap-1">
                        <AlertCircle className="w-3 h-3" /> {formErrors.address}
                      </p>
                    )}
                  </div>

                  <div>
                    <label htmlFor="checkout-orderNotes" className="block text-xs font-bold text-gray-700 mb-1">
                      Order Notes (Optional)
                    </label>
                    <input
                      type="text"
                      id="checkout-orderNotes"
                      value={formData.orderNotes}
                      onChange={(e) => setFormData({ ...formData, orderNotes: e.target.value })}
                      placeholder="e.g. Ring the bell twice, keep condiments separate"
                      className="w-full px-4 py-3 rounded-xl border border-gray-200 text-sm focus:outline-none focus:border-[#F77F00]"
                    />
                  </div>
                </div>
              </div>

              {/* Step 3: Payment Method Selection */}
              <div className="bg-white rounded-3xl border border-gray-100 p-6 sm:p-8 shadow-sm">
                <div className="flex items-center gap-3 mb-6 pb-3 border-b border-gray-100">
                  <div className="w-8 h-8 rounded-full bg-[#FCBF49] text-[#1F1F1F] flex items-center justify-center font-black text-xs">
                    3
                  </div>
                  <h2 className="text-lg font-black text-[#1F1F1F]">
                    Payment Method
                  </h2>
                </div>

                <div className="space-y-3">
                  {paymentOptions.map((opt) => {
                    const Icon = opt.icon;
                    const isSelected = paymentMethod === opt.id;

                    return (
                      <label
                        key={opt.id}
                        className={`flex items-start gap-4 p-4 rounded-2xl border-2 transition-all cursor-pointer ${
                          isSelected
                            ? 'border-[#F77F00] bg-[#FFF8EF]/60 shadow-xs'
                            : 'border-gray-100 hover:border-gray-200 bg-white'
                        }`}
                      >
                        <input
                          type="radio"
                          name="paymentMethod"
                          checked={isSelected}
                          onChange={() => setPaymentMethod(opt.id)}
                          className="mt-1 text-[#F77F00] focus:ring-[#F77F00]"
                        />

                        <div className="flex-1">
                          <div className="flex items-center gap-2">
                            <Icon className={`w-4 h-4 ${isSelected ? 'text-[#F77F00]' : 'text-gray-400'}`} />
                            <span className="text-sm font-bold text-[#1F1F1F]">{opt.label}</span>
                          </div>
                          <p className="text-xs text-gray-500 mt-1">{opt.desc}</p>
                        </div>

                        {isSelected && (
                          <span className="w-5 h-5 rounded-full bg-[#F77F00] text-white flex items-center justify-center shrink-0">
                            <Check className="w-3 h-3 stroke-[3]" />
                          </span>
                        )}
                      </label>
                    );
                  })}
                </div>
              </div>

              {/* Mobile Only: Order Summary displayed right above submit button as requested */}
              <div className="lg:hidden mt-6">
                <OrderSummaryBox />
              </div>

              {/* Place Order CTA Button */}
              <div className="pt-2">
                <button
                  type="submit"
                  id="checkout-place-order-btn"
                  disabled={isSubmitting}
                  className="w-full py-4 px-8 rounded-2xl bg-gradient-to-r from-[#D62828] via-[#E63946] to-[#F77F00] hover:from-[#B71C1C] hover:to-[#E06F00] text-white font-black text-base shadow-xl shadow-[#D62828]/25 transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50 active:scale-98"
                >
                  {isSubmitting ? (
                    <span>Processing Order...</span>
                  ) : (
                    <>
                      <ShieldCheck className="w-5 h-5" />
                      <span>
                        Place Order • {RESTAURANT_INFO.currency} {total.toLocaleString()}
                      </span>
                    </>
                  )}
                </button>

                <p className="text-center text-xs text-gray-400 mt-3 flex items-center justify-center gap-1.5">
                  <ShieldCheck className="w-3.5 h-3.5 text-[#2A9D8F]" />
                  <span>Your information is safe and never shared.</span>
                </p>
              </div>

            </div>

            {/* Right Column: Desktop Order Summary (5 cols) */}
            <div className="hidden lg:block lg:col-span-5 sticky top-28 space-y-4">
              <OrderSummaryBox />
            </div>

          </div>
        </form>

      </div>
    </div>
  );
};
