import React, { useState, useEffect } from 'react';
import {
  MapPin,
  Phone,
  MessageCircle,
  Mail,
  Clock,
  Send,
  CheckCircle2,
  Navigation,
  Sparkles,
} from 'lucide-react';
import { Breadcrumb } from '../components/Breadcrumb';
import { RESTAURANT_INFO, getWhatsAppUrl } from '../config/restaurant';

export const ContactPage: React.FC = () => {
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    email: '',
    message: '',
  });

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);

  useEffect(() => {
    window.scrollTo(0, 0);
    document.title = `Contact Us | ${RESTAURANT_INFO.name}`;
  }, []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    // Simulate API submission
    setTimeout(() => {
      setIsSubmitting(false);
      setIsSubmitted(true);
      setFormData({ name: '', phone: '', email: '', message: '' });
    }, 600);
  };

  return (
    <div className="min-h-screen bg-[#FFF8EF] py-8 sm:py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Breadcrumb */}
        <Breadcrumb items={[{ label: 'Contact Us' }]} />

        {/* Page Header */}
        <div className="text-center max-w-3xl mx-auto mt-4 mb-12">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#FFECEC] text-[#D62828] text-xs font-black uppercase tracking-wider mb-3">
            <Phone className="w-3.5 h-3.5" />
            <span>We&apos;re Here to Serve You</span>
          </div>

          <h1 className="text-3xl sm:text-4xl lg:text-5xl font-black text-[#1F1F1F] font-display tracking-tight">
            Get In Touch With Waseem Food
          </h1>

          <p className="mt-3 text-sm sm:text-base text-gray-600 leading-relaxed">
            Have a question regarding an active order, bulk event catering, or feedback? Send us a message or contact our hotline directly.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 mb-12">
          
          {/* Left Column: Contact Details Cards (5 cols) */}
          <div className="lg:col-span-5 space-y-4">
            
            {/* Address Card */}
            <div className="p-6 rounded-3xl bg-white border border-gray-100 shadow-sm flex items-start gap-4">
              <div className="w-12 h-12 rounded-2xl bg-[#FFECEC] text-[#D62828] flex items-center justify-center shrink-0">
                <MapPin className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-sm font-extrabold text-[#1F1F1F] uppercase tracking-wider text-gray-400">
                  Restaurant Address
                </h3>
                <p className="text-sm sm:text-base font-bold text-[#1F1F1F] mt-1 leading-snug">
                  {RESTAURANT_INFO.address}
                </p>
                <span className="text-xs text-gray-500 block mt-0.5">{RESTAURANT_INFO.city}, Pakistan</span>
              </div>
            </div>

            {/* Hotline & WhatsApp */}
            <div className="p-6 rounded-3xl bg-white border border-gray-100 shadow-sm flex items-start gap-4">
              <div className="w-12 h-12 rounded-2xl bg-[#FFF4E5] text-[#F77F00] flex items-center justify-center shrink-0">
                <Phone className="w-6 h-6" />
              </div>
              <div className="flex-1">
                <h3 className="text-sm font-extrabold text-[#1F1F1F] uppercase tracking-wider text-gray-400">
                  Order Hotline
                </h3>
                <p className="text-base font-black text-[#D62828] mt-1">
                  <a href={`tel:${RESTAURANT_INFO.phone}`} className="hover:underline">
                    {RESTAURANT_INFO.displayPhone}
                  </a>
                </p>
                <div className="mt-2">
                  <a
                    href={getWhatsAppUrl()}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1.5 text-xs font-bold text-[#25D366] hover:underline"
                  >
                    <MessageCircle className="w-4 h-4" />
                    <span>WhatsApp: {RESTAURANT_INFO.whatsappDisplay}</span>
                  </a>
                </div>
              </div>
            </div>

            {/* Email */}
            <div className="p-6 rounded-3xl bg-white border border-gray-100 shadow-sm flex items-start gap-4">
              <div className="w-12 h-12 rounded-2xl bg-[#FCBF49]/20 text-[#1F1F1F] flex items-center justify-center shrink-0">
                <Mail className="w-6 h-6 text-[#F77F00]" />
              </div>
              <div>
                <h3 className="text-sm font-extrabold text-[#1F1F1F] uppercase tracking-wider text-gray-400">
                  Email Support
                </h3>
                <p className="text-sm sm:text-base font-bold text-[#1F1F1F] mt-1">
                  <a href={`mailto:${RESTAURANT_INFO.email}`} className="hover:text-[#D62828] transition-colors">
                    {RESTAURANT_INFO.email}
                  </a>
                </p>
                <span className="text-xs text-gray-500 block mt-0.5">
                  Orders: {RESTAURANT_INFO.ordersEmail}
                </span>
              </div>
            </div>

            {/* Operating Hours */}
            <div className="p-6 rounded-3xl bg-white border border-gray-100 shadow-sm flex items-start gap-4">
              <div className="w-12 h-12 rounded-2xl bg-emerald-50 text-emerald-600 flex items-center justify-center shrink-0">
                <Clock className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-sm font-extrabold text-[#1F1F1F] uppercase tracking-wider text-gray-400">
                  Opening Hours
                </h3>
                <p className="text-sm sm:text-base font-bold text-[#1F1F1F] mt-1">
                  {RESTAURANT_INFO.openingHours}
                </p>
                <span className="text-xs text-emerald-600 font-bold block mt-0.5">
                  ● Kitchen is Open &amp; Delivering Now
                </span>
              </div>
            </div>

          </div>

          {/* Right Column: Contact Form (7 cols) */}
          <div className="lg:col-span-7">
            <div className="p-6 sm:p-10 rounded-3xl bg-white border border-gray-100 shadow-md">
              <h2 className="text-2xl font-black text-[#1F1F1F] font-display">
                Send Us a Message
              </h2>
              <p className="text-xs sm:text-sm text-gray-500 mt-1 mb-6">
                Fill out the form below and our customer relations team will get back to you promptly.
              </p>

              {isSubmitted ? (
                <div className="p-6 rounded-2xl bg-[#FFF8EF] border border-[#FCBF49] text-center">
                  <div className="w-14 h-14 rounded-full bg-[#2A9D8F] text-white flex items-center justify-center mx-auto mb-3">
                    <CheckCircle2 className="w-8 h-8" />
                  </div>
                  <h3 className="text-lg font-bold text-[#1F1F1F]">Message Sent Successfully!</h3>
                  <p className="text-xs sm:text-sm text-gray-600 mt-1">
                    Thank you for reaching out to Waseem Food. We have received your message and will respond shortly.
                  </p>
                  <button
                    type="button"
                    onClick={() => setIsSubmitted(false)}
                    className="mt-4 text-xs font-bold text-[#D62828] hover:underline"
                  >
                    Send another message
                  </button>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label htmlFor="contact-name" className="block text-xs font-bold text-gray-700 mb-1">
                        Full Name *
                      </label>
                      <input
                        type="text"
                        id="contact-name"
                        required
                        value={formData.name}
                        onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                        placeholder="e.g. Muhammad Ali"
                        className="w-full px-4 py-3 rounded-xl border border-gray-200 text-sm focus:outline-none focus:border-[#F77F00] focus:ring-2 focus:ring-[#F77F00]/20"
                      />
                    </div>

                    <div>
                      <label htmlFor="contact-phone" className="block text-xs font-bold text-gray-700 mb-1">
                        Phone Number *
                      </label>
                      <input
                        type="tel"
                        id="contact-phone"
                        required
                        value={formData.phone}
                        onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                        placeholder="0300-1234567"
                        className="w-full px-4 py-3 rounded-xl border border-gray-200 text-sm focus:outline-none focus:border-[#F77F00] focus:ring-2 focus:ring-[#F77F00]/20"
                      />
                    </div>
                  </div>

                  <div>
                    <label htmlFor="contact-email" className="block text-xs font-bold text-gray-700 mb-1">
                      Email Address *
                    </label>
                    <input
                      type="email"
                      id="contact-email"
                      required
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      placeholder="your.email@example.com"
                      className="w-full px-4 py-3 rounded-xl border border-gray-200 text-sm focus:outline-none focus:border-[#F77F00] focus:ring-2 focus:ring-[#F77F00]/20"
                    />
                  </div>

                  <div>
                    <label htmlFor="contact-message" className="block text-xs font-bold text-gray-700 mb-1">
                      Message / Special Query *
                    </label>
                    <textarea
                      id="contact-message"
                      rows={4}
                      required
                      value={formData.message}
                      onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                      placeholder="How can we help you today? Please share your thoughts..."
                      className="w-full px-4 py-3 rounded-xl border border-gray-200 text-sm focus:outline-none focus:border-[#F77F00] focus:ring-2 focus:ring-[#F77F00]/20 resize-none"
                    />
                  </div>

                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="w-full py-4 px-6 rounded-2xl bg-gradient-to-r from-[#F77F00] to-[#E06F00] hover:from-[#E06F00] hover:to-[#D62828] text-white font-extrabold text-sm shadow-md shadow-[#F77F00]/25 transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
                  >
                    {isSubmitting ? (
                      <span>Sending...</span>
                    ) : (
                      <>
                        <Send className="w-4 h-4" />
                        <span>Send Message</span>
                      </>
                    )}
                  </button>
                </form>
              )}
            </div>
          </div>

        </div>

        {/* Google Maps Visual Interactive Placeholder */}
        <div className="bg-white rounded-3xl border border-gray-100 shadow-md overflow-hidden">
          <div className="p-4 sm:p-6 bg-[#FFF8EF] border-b border-[#FCBF49]/30 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-[#D62828] text-white flex items-center justify-center">
                <Navigation className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-bold text-sm text-[#1F1F1F]">Location Map &amp; Directions</h3>
                <p className="text-xs text-gray-500">Main Boulevard, Gulberg III, Lahore, Pakistan</p>
              </div>
            </div>

            <a
              href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(RESTAURANT_INFO.name + ' ' + RESTAURANT_INFO.address)}`}
              target="_blank"
              rel="noopener noreferrer"
              className="px-4 py-2 rounded-xl bg-[#1F1F1F] text-white text-xs font-bold hover:bg-[#D62828] transition-colors flex items-center gap-1.5 self-start sm:self-auto"
            >
              <span>Open in Google Maps</span>
              <Navigation className="w-3.5 h-3.5" />
            </a>
          </div>

          {/* Styled Map Canvas View */}
          <div className="relative w-full h-80 bg-[#E5E3DF] flex items-center justify-center overflow-hidden">
            {/* Map Grid Patterns */}
            <div className="absolute inset-0 opacity-40 bg-[radial-gradient(#9ca3af_1px,transparent_1px)] [background-size:16px_16px]" />
            
            {/* Simulated Road Lines */}
            <div className="absolute w-full h-3 bg-white top-1/2 -translate-y-1/2 shadow-xs" />
            <div className="absolute h-full w-4 bg-white left-1/3 shadow-xs" />
            <div className="absolute h-full w-3 bg-[#FCBF49]/50 left-2/3 shadow-xs" />
            <div className="absolute w-full h-2 bg-white top-1/4 shadow-xs" />

            {/* Pin Center */}
            <div className="relative z-10 flex flex-col items-center">
              <div className="w-14 h-14 rounded-full bg-[#D62828] text-white shadow-2xl flex items-center justify-center animate-bounce border-2 border-white">
                <MapPin className="w-8 h-8 fill-white" />
              </div>
              <div className="mt-2 px-4 py-2 rounded-xl bg-white shadow-lg border border-gray-100 text-center">
                <span className="font-black text-xs text-[#1F1F1F] block">{RESTAURANT_INFO.name}</span>
                <span className="text-[11px] text-gray-500">Gulberg III, Lahore</span>
              </div>
            </div>
          </div>
        </div>

      </div>
    </div>
  );
};
