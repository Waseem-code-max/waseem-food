import React, { useEffect } from 'react';
import { Link } from 'react-router-dom';
import {
  Heart,
  Award,
  ShieldCheck,
  Users,
  Flame,
  Clock,
  ArrowRight,
  CheckCircle2,
} from 'lucide-react';
import { Breadcrumb } from '../components/Breadcrumb';
import { RESTAURANT_INFO } from '../config/restaurant';

export const AboutPage: React.FC = () => {
  useEffect(() => {
    window.scrollTo(0, 0);
    document.title = `About Us | ${RESTAURANT_INFO.name}`;
  }, []);

  return (
    <div className="min-h-screen bg-[#FFF8EF] py-8 sm:py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Breadcrumb */}
        <Breadcrumb items={[{ label: 'About Us' }]} />

        {/* Hero Banner */}
        <div className="mt-4 text-center max-w-3xl mx-auto mb-14">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#FFECEC] text-[#D62828] text-xs font-black uppercase tracking-wider mb-3">
            <Heart className="w-3.5 h-3.5 fill-current" />
            <span>Our Heritage &amp; Passion</span>
          </div>

          <h1 className="text-3xl sm:text-4xl lg:text-5xl font-black text-[#1F1F1F] font-display tracking-tight leading-tight">
            Crafting Unforgettable Pakistani Food Experiences
          </h1>

          <p className="mt-4 text-base sm:text-lg text-gray-700 leading-relaxed">
            Welcome to <strong>{RESTAURANT_INFO.name}</strong>, where authentic Lahori culinary traditions meet modern culinary speed and unmatched hygiene.
          </p>
        </div>

        {/* Story Section */}
        <div className="bg-white rounded-3xl border border-gray-100 p-6 sm:p-10 lg:p-12 shadow-md grid grid-cols-1 lg:grid-cols-12 gap-10 items-center mb-16">
          <div className="lg:col-span-6 space-y-4 text-sm sm:text-base text-gray-700 leading-relaxed">
            <h2 className="text-2xl sm:text-3xl font-black text-[#1F1F1F] font-display">
              Our Story: Rooted in Lahori Tradition
            </h2>
            <p>
              Food is not merely sustenance in Pakistan—it is an art form, a warm gesture of hospitality, and the heartbeat of every family gathering. <strong>Waseem Food</strong> was born out of a profound love for traditional slow-cooked flavors.
            </p>
            <p>
              Dissatisfied with mass-produced, bland commercial food, our founders set out with a clear purpose: prepare food the way our elders did, using honest ingredients, fragrant whole spices roasted in-house, and premium cuts of meat.
            </p>
            <p>
              Over the years, we expanded our offerings to include contemporary fast-food sensations like our iconic <em>Crispy Zinger Burger</em> and loaded fries, giving our guests the best of both worlds under one trusted roof.
            </p>

            <div className="pt-4 grid grid-cols-2 gap-4">
              <div className="p-4 rounded-2xl bg-[#FFF8EF] border border-[#FCBF49]/30">
                <span className="text-2xl font-black text-[#D62828] block font-display">15+</span>
                <span className="text-xs font-bold text-gray-700">Years of Culinary Heritage</span>
              </div>
              <div className="p-4 rounded-2xl bg-[#FFF8EF] border border-[#FCBF49]/30">
                <span className="text-2xl font-black text-[#F77F00] block font-display">12,000+</span>
                <span className="text-xs font-bold text-gray-700">Satisfied Monthly Diners</span>
              </div>
            </div>
          </div>

          <div className="lg:col-span-6 relative">
            <div className="rounded-3xl overflow-hidden shadow-xl border-4 border-white">
              <img
                src="https://images.unsplash.com/photo-1555396273-367ea4eb4db5?auto=format&fit=crop&w=900&q=80"
                alt="Waseem Food Kitchen and staff"
                className="w-full h-[380px] sm:h-[450px] object-cover"
              />
            </div>
          </div>
        </div>

        {/* 4 Pillars Grid: Mission, Food Quality, Fresh Ingredients, Customer Satisfaction */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
          {[
            {
              icon: Award,
              title: "Our Mission",
              desc: "To deliver authentic, wholesome, and delicious Pakistani and fast-food meals to every home without compromising on affordability or hygiene.",
              color: "text-[#D62828] bg-[#FFECEC]",
            },
            {
              icon: Flame,
              title: "Food Quality",
              desc: "We adhere to century-old dum cooking methods and open charcoal grills to infuse authentic aroma that you can smell before taking the first bite.",
              color: "text-[#F77F00] bg-[#FFF4E5]",
            },
            {
              icon: ShieldCheck,
              title: "Fresh Ingredients",
              desc: "100% Halal farm-fresh chicken and vegetables delivered daily. We never freeze our prepped meats or reuse cooking oils.",
              color: "text-[#2A9D8F] bg-[#2A9D8F]/10",
            },
            {
              icon: Users,
              title: "Customer Delight",
              desc: "Your meal arrives hot, properly packed in insulated temperature-locking containers, handled by courteous dispatch riders.",
              color: "text-[#FCBF49] bg-[#FCBF49]/20",
            },
          ].map((item, idx) => {
            const Icon = item.icon;
            return (
              <div
                key={idx}
                className="p-6 rounded-3xl bg-white border border-gray-100 shadow-2xs hover:shadow-xl transition-all hover:-translate-y-1"
              >
                <div className={`w-12 h-12 rounded-2xl ${item.color} flex items-center justify-center mb-4`}>
                  <Icon className="w-6 h-6" />
                </div>
                <h3 className="text-lg font-bold text-[#1F1F1F] mb-2">{item.title}</h3>
                <p className="text-xs sm:text-sm text-gray-600 leading-relaxed">{item.desc}</p>
              </div>
            );
          })}
        </div>

        {/* Quality Standards Checklist */}
        <div className="p-8 sm:p-10 rounded-3xl bg-[#1F1F1F] text-white shadow-xl mb-16">
          <div className="max-w-3xl">
            <span className="text-xs font-black text-[#FCBF49] uppercase tracking-wider">
              Hygienic &amp; Halal Guarantee
            </span>
            <h3 className="text-2xl sm:text-3xl font-black mt-1 font-display">
              The Waseem Food Kitchen Standard
            </h3>
            <p className="text-gray-400 text-sm mt-2 leading-relaxed">
              Every dish served under our banner follows stringent food health and safety guidelines. We invite you to experience the difference.
            </p>

            <div className="mt-6 grid grid-cols-1 sm:grid-cols-2 gap-3.5">
              {[
                "Government food safety authority compliant",
                "Pure aromatic spices with no artificial coloring",
                "Sanitized stainless steel food preparation stations",
                "Eco-friendly tamper-proof delivery packaging"
              ].map((text, i) => (
                <div key={i} className="flex items-center gap-2.5 text-xs sm:text-sm text-gray-200">
                  <CheckCircle2 className="w-4 h-4 text-[#FCBF49] shrink-0" />
                  <span>{text}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Final CTA */}
        <div className="text-center py-10">
          <h2 className="text-2xl sm:text-3xl font-black text-[#1F1F1F] font-display">
            Ready to Taste the Difference?
          </h2>
          <p className="text-sm text-gray-600 mt-2 max-w-md mx-auto">
            Order online today and experience the freshest flavors of Lahore delivered hot to your door.
          </p>
          <div className="mt-6">
            <Link
              to="/menu"
              className="px-8 py-4 rounded-2xl bg-[#D62828] hover:bg-[#B71C1C] text-white font-black text-sm shadow-lg shadow-[#D62828]/30 transition-all inline-flex items-center gap-2"
            >
              <span>Explore Our Menu</span>
              <ArrowRight className="w-4 h-4" />
            </Link>
          </div>
        </div>

      </div>
    </div>
  );
};
