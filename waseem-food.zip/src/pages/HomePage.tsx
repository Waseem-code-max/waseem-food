import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, Flame, Sparkles, Utensils, Star, Quote } from 'lucide-react';
import { Hero } from '../components/Hero';
import { CategoryList } from '../components/CategoryList';
import { ProductGrid } from '../components/ProductGrid';
import { DealsSection } from '../components/DealsSection';
import { WhyChooseUs } from '../components/WhyChooseUs';
import { AboutSection } from '../components/AboutSection';
import { getProducts, getPopularProducts } from '../services/api';
import { Product } from '../types';
import { RESTAURANT_INFO } from '../config/restaurant';

export const HomePage: React.FC = () => {
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [allProducts, setAllProducts] = useState<Product[]>([]);
  const [popularProducts, setPopularProducts] = useState<Product[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    window.scrollTo(0, 0);
    document.title = `${RESTAURANT_INFO.name} | Delicious Pakistani Food, Made Fresh`;

    async function loadData() {
      setIsLoading(true);
      const [prods, pop] = await Promise.all([getProducts(), getPopularProducts(6)]);
      setAllProducts(prods);
      setPopularProducts(pop);
      setIsLoading(false);
    }
    loadData();
  }, []);

  // Filter products by selected category dynamically without page refresh
  const filteredProducts =
    selectedCategory.toLowerCase() === 'all'
      ? allProducts
      : allProducts.filter(
          (p) => p.category.toLowerCase() === selectedCategory.toLowerCase()
        );

  // Category item counts
  const categoryCounts = allProducts.reduce((acc, p) => {
    acc[p.category] = (acc[p.category] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);
  categoryCounts['All'] = allProducts.length;

  return (
    <div className="min-h-screen bg-[#FFF8EF]">
      {/* 1. Hero Section */}
      <Hero />

      {/* 2. Horizontal Food Category Filter Section */}
      <section className="py-8 bg-white border-b border-gray-100 sticky top-[69px] z-30 shadow-2xs backdrop-blur-md bg-white/95">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-[#D62828] animate-pulse" />
              <h2 className="text-xs sm:text-sm font-extrabold uppercase tracking-wider text-gray-500">
                Browse Categories
              </h2>
            </div>
            <Link
              to="/menu"
              className="text-xs font-bold text-[#D62828] hover:text-[#B71C1C] flex items-center gap-1"
            >
              <span>Full Menu</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </Link>
          </div>

          <CategoryList
            activeCategory={selectedCategory}
            onSelectCategory={(cat) => {
              if (cat.toLowerCase() === 'deals') {
                const el = document.getElementById('special-deals-section');
                if (el) el.scrollIntoView({ behavior: 'smooth' });
                return;
              }
              setSelectedCategory(cat);
            }}
            itemCounts={categoryCounts}
          />
        </div>
      </section>

      {/* Dynamic Filtered Menu Section (When category is selected) */}
      {selectedCategory !== 'All' && (
        <section className="py-12 bg-[#FFF8EF]">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex items-center justify-between mb-6">
              <div>
                <h3 className="text-2xl font-black text-[#1F1F1F]">
                  {selectedCategory} Specials
                </h3>
                <p className="text-xs sm:text-sm text-gray-500 mt-0.5">
                  Showing {filteredProducts.length} items in {selectedCategory}
                </p>
              </div>

              <button
                type="button"
                onClick={() => setSelectedCategory('All')}
                className="text-xs font-bold text-[#D62828] bg-white border border-[#D62828]/30 px-3 py-1.5 rounded-xl hover:bg-[#FFECEC] transition-colors"
              >
                Reset to All
              </button>
            </div>

            <ProductGrid products={filteredProducts} />
          </div>
        </section>
      )}

      {/* 3. Popular This Week Section */}
      <section className="py-16 bg-[#FFF8EF]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row md:items-end justify-between mb-10 gap-4">
            <div>
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#FCBF49]/30 text-[#1F1F1F] text-xs font-black uppercase tracking-wider mb-3">
                <Sparkles className="w-3.5 h-3.5 text-[#F77F00]" />
                <span>Top Customer Picks</span>
              </div>
              <h2 className="text-3xl sm:text-4xl font-black text-[#1F1F1F] font-display tracking-tight">
                Popular This Week
              </h2>
              <p className="text-gray-600 text-sm sm:text-base mt-2 max-w-xl">
                The most loved Pakistani dishes ordered across our Lahore kitchens right now. Authentic recipes with irresistible aromas.
              </p>
            </div>

            <Link
              to="/menu"
              className="inline-flex items-center gap-2 text-sm font-bold text-[#D62828] hover:text-[#B71C1C] transition-colors group self-start md:self-auto"
            >
              <span>Explore All Dishes</span>
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </Link>
          </div>

          {isLoading ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {[1, 2, 3, 4, 5, 6].map((n) => (
                <div key={n} className="h-80 bg-white rounded-2xl animate-pulse" />
              ))}
            </div>
          ) : (
            <ProductGrid
              products={selectedCategory === 'All' ? popularProducts : filteredProducts.slice(0, 6)}
              columns="3"
            />
          )}

          <div className="mt-12 text-center">
            <Link
              to="/menu"
              className="inline-flex items-center gap-2 px-8 py-4 rounded-2xl bg-white border-2 border-[#FCBF49] hover:border-[#F77F00] text-[#1F1F1F] hover:text-[#D62828] font-bold text-sm shadow-xs hover:shadow-md transition-all active:scale-95"
            >
              <Utensils className="w-4 h-4 text-[#F77F00]" />
              <span>View Complete Menu with All {allProducts.length} Items</span>
            </Link>
          </div>
        </div>
      </section>

      {/* 4. Special Deals Section */}
      <DealsSection />

      {/* 5. Why Choose Waseem Food */}
      <WhyChooseUs />

      {/* 6. About Section */}
      <AboutSection />

      {/* 7. Testimonials / Social Proof Section */}
      <section className="py-16 sm:py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-2xl mx-auto mb-12">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#FFECEC] text-[#D62828] text-xs font-black uppercase tracking-wider mb-3">
              <Star className="w-3.5 h-3.5 fill-current" />
              <span>Customer Love</span>
            </div>
            <h2 className="text-3xl sm:text-4xl font-black text-[#1F1F1F] font-display tracking-tight">
              What Foodies Say About Us
            </h2>
            <p className="text-gray-600 text-sm sm:text-base mt-2">
              Over 12,000+ satisfied foodies order their weekly Biryani and Zinger cravings from Waseem Food.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[
              {
                quote: "The Chicken Biryani has the true authentic Lahore dum flavor. Perfectly spiced, aromatic basmati, and the chicken was fall-off-the-bone tender. Delivered in under 35 mins!",
                name: "Hamza Tariq",
                location: "Gulberg, Lahore",
                dish: "Special Chicken Biryani",
                rating: 5,
              },
              {
                quote: "Their Waseem Family Deal is unbeatable value. The zinger burger is way crunchier and juicier than big international fast-food chains, and the garlic mayo fries were delicious.",
                name: "Ayesha Malik",
                location: "DHA Phase 5, Lahore",
                dish: "Waseem Family Deal",
                rating: 5,
              },
              {
                quote: "Ordered the BBQ Platter for our family weekend get-together. The Seekh Kababs and Malai Boti were smoky and succulent. Very impressed with the packaging and hygiene.",
                name: "Usman Rafique",
                location: "Model Town, Lahore",
                dish: "Royal BBQ Platter",
                rating: 5,
              },
            ].map((review, i) => (
              <div
                key={i}
                className="p-6 rounded-3xl bg-[#FFF8EF]/50 border border-gray-100 flex flex-col justify-between shadow-2xs hover:shadow-lg transition-shadow"
              >
                <div>
                  <Quote className="w-8 h-8 text-[#FCBF49] mb-4 opacity-70" />
                  <p className="text-sm text-gray-700 italic leading-relaxed">
                    &ldquo;{review.quote}&rdquo;
                  </p>
                </div>

                <div className="mt-6 pt-4 border-t border-gray-200/50 flex items-center justify-between">
                  <div>
                    <h4 className="font-bold text-sm text-[#1F1F1F]">{review.name}</h4>
                    <span className="text-xs text-gray-500">{review.location}</span>
                  </div>
                  <div className="text-right">
                    <span className="text-[10px] font-bold text-[#D62828] bg-[#FFECEC] px-2 py-0.5 rounded-md block mb-1">
                      {review.dish}
                    </span>
                    <div className="flex text-[#F77F00] justify-end">
                      {'★'.repeat(review.rating)}
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};
