import React, { useState, useEffect } from 'react';
import { Tag, Sparkles, Flame, Users } from 'lucide-react';
import { Breadcrumb } from '../components/Breadcrumb';
import { DealCard } from '../components/DealCard';
import { getDeals } from '../services/api';
import { Deal } from '../types';
import { RESTAURANT_INFO } from '../config/restaurant';

export const DealsPage: React.FC = () => {
  const [deals, setDeals] = useState<Deal[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    window.scrollTo(0, 0);
    document.title = `Special Deals & Combos | ${RESTAURANT_INFO.name}`;

    async function loadDeals() {
      setIsLoading(true);
      const data = await getDeals();
      setDeals(data);
      setIsLoading(false);
    }
    loadDeals();
  }, []);

  return (
    <div className="min-h-screen bg-[#FFF8EF] py-8 sm:py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Breadcrumb */}
        <Breadcrumb items={[{ label: 'Special Deals' }]} />

        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mt-4 mb-12">
          <div className="inline-flex items-center gap-1.5 px-3.5 py-1 rounded-full bg-[#FFECEC] text-[#D62828] text-xs font-black uppercase tracking-wider mb-3">
            <Flame className="w-3.5 h-3.5 fill-current" />
            <span>Value Combos &amp; Family Feasts</span>
          </div>

          <h1 className="text-3xl sm:text-4xl lg:text-5xl font-black text-[#1F1F1F] font-display tracking-tight">
            Special Deals &amp; Combos
          </h1>

          <p className="mt-3 text-sm sm:text-base text-gray-600 leading-relaxed">
            Feed your friends, family, or late-night study cravings with our discounted value packages. Generous portions, authentic Pakistani sides, and crisp cold drinks included.
          </p>
        </div>

        {/* Deals List */}
        {isLoading ? (
          <div className="space-y-6">
            {[1, 2, 3].map((n) => (
              <div key={n} className="h-64 bg-white rounded-3xl animate-pulse" />
            ))}
          </div>
        ) : (
          <div className="space-y-8">
            {deals.map((deal) => (
              <DealCard key={deal.id} deal={deal} />
            ))}
          </div>
        )}

        {/* Value Guarantee Note */}
        <div className="mt-16 p-8 rounded-3xl bg-white border border-dashed border-[#FCBF49] text-center max-w-2xl mx-auto">
          <div className="w-12 h-12 rounded-2xl bg-[#FFF8EF] text-[#F77F00] flex items-center justify-center mx-auto mb-3">
            <Sparkles className="w-6 h-6" />
          </div>
          <h3 className="text-lg font-bold text-[#1F1F1F]">
            Every Deal is Prepared Fresh Upon Order
          </h3>
          <p className="text-xs sm:text-sm text-gray-500 mt-1">
            No pre-cooked warming drawers. Your burgers are fried fresh, your biryani is ladled steaming hot, and your naans are pulled right from the tandoor.
          </p>
        </div>

      </div>
    </div>
  );
};
