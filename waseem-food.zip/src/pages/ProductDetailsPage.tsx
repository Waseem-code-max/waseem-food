import React, { useState, useEffect } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import {
  Heart,
  ShoppingBag,
  Clock,
  Users,
  Flame,
  ShieldCheck,
  MessageCircle,
  Share2,
  Check,
  ArrowLeft,
} from 'lucide-react';
import { Breadcrumb } from '../components/Breadcrumb';
import { Rating } from '../components/Rating';
import { QuantitySelector } from '../components/QuantitySelector';
import { ProductCard } from '../components/ProductCard';
import { getProductBySlug, getProductsByCategory } from '../services/api';
import { Product } from '../types';
import { useCart } from '../context/CartContext';
import { RESTAURANT_INFO, getWhatsAppUrl } from '../config/restaurant';

export const ProductDetailsPage: React.FC = () => {
  const { slug } = useParams<{ slug: string }>();
  const navigate = useNavigate();
  const [product, setProduct] = useState<Product | null>(null);
  const [relatedProducts, setRelatedProducts] = useState<Product[]>([]);
  const [quantity, setQuantity] = useState(1);
  const [specialNotes, setSpecialNotes] = useState('');
  const [isLoading, setIsLoading] = useState(true);
  const [isCopied, setIsCopied] = useState(false);

  const { addToCart, isFavorite, toggleFavorite } = useCart();

  useEffect(() => {
    window.scrollTo(0, 0);
    setQuantity(1);
    setSpecialNotes('');

    async function loadItem() {
      if (!slug) return;
      setIsLoading(true);
      const data = await getProductBySlug(slug);
      if (!data) {
        setIsLoading(false);
        return;
      }
      setProduct(data);
      document.title = `${data.name} | ${RESTAURANT_INFO.name}`;

      // Load related items from same category
      const related = await getProductsByCategory(data.category);
      setRelatedProducts(related.filter((p) => p.id !== data.id).slice(0, 4));
      setIsLoading(false);
    }

    loadItem();
  }, [slug]);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-[#FFF8EF] py-16 px-4">
        <div className="max-w-5xl mx-auto bg-white rounded-3xl p-8 animate-pulse h-96" />
      </div>
    );
  }

  if (!product) {
    return (
      <div className="min-h-screen bg-[#FFF8EF] py-20 px-4 text-center">
        <div className="max-w-md mx-auto bg-white rounded-3xl p-8 shadow-sm">
          <h2 className="text-2xl font-black text-[#1F1F1F]">Dish Not Found</h2>
          <p className="text-gray-500 text-sm mt-2">
            The dish you are looking for may have been moved or is currently unavailable.
          </p>
          <Link
            to="/menu"
            className="mt-6 inline-flex items-center gap-2 px-6 py-3 rounded-2xl bg-[#D62828] text-white font-bold text-xs shadow-md"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Return to Menu</span>
          </Link>
        </div>
      </div>
    );
  }

  const favorited = isFavorite(product.id);

  const handleAddToCart = () => {
    addToCart(product, quantity, specialNotes);
  };

  const handleShare = () => {
    if (navigator.clipboard) {
      navigator.clipboard.writeText(window.location.href);
      setIsCopied(true);
      setTimeout(() => setIsCopied(false), 2500);
    }
  };

  const whatsappMessage = `Hello ${RESTAURANT_INFO.name}, I want to order "${product.name}" (Qty: ${quantity}). Price: ${RESTAURANT_INFO.currency} ${(product.price * quantity).toLocaleString()}. Is it available right now?`;

  return (
    <div className="min-h-screen bg-[#FFF8EF] py-6 sm:py-10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Breadcrumb Navigation: Home > Menu > Product Name */}
        <Breadcrumb
          items={[
            { label: 'Menu', to: '/menu' },
            { label: product.category, to: `/menu?category=${encodeURIComponent(product.category)}` },
            { label: product.name },
          ]}
        />

        {/* Main Product Card */}
        <div className="mt-4 bg-white rounded-3xl border border-gray-100 shadow-lg overflow-hidden grid grid-cols-1 lg:grid-cols-12 gap-0">
          
          {/* Left Column: Product Image Canvas */}
          <div className="lg:col-span-6 relative bg-gray-900 min-h-[340px] sm:min-h-[460px] overflow-hidden flex items-center justify-center">
            <img
              src={product.image}
              alt={product.name}
              className="w-full h-full object-cover object-center"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/40 via-transparent to-black/20 pointer-events-none" />

            {/* Badges on Image */}
            <div className="absolute top-4 left-4 flex flex-wrap gap-2">
              {product.discount && product.discount > 0 && (
                <span className="bg-[#FCBF49] text-[#1F1F1F] text-xs font-black px-3 py-1.5 rounded-full shadow-md uppercase tracking-wide border border-white/50">
                  {product.discount}% OFF
                </span>
              )}
              {product.featured && (
                <span className="bg-[#D62828] text-white text-xs font-bold px-3 py-1.5 rounded-full shadow-md">
                  Chef Choice
                </span>
              )}
            </div>

            {/* Favorite & Share Buttons */}
            <div className="absolute top-4 right-4 flex items-center gap-2">
              <button
                type="button"
                onClick={handleShare}
                aria-label="Share product"
                className="w-10 h-10 rounded-full bg-white/90 backdrop-blur-md text-gray-700 hover:text-[#D62828] flex items-center justify-center shadow-md transition-colors"
                title="Copy link"
              >
                {isCopied ? <Check className="w-4 h-4 text-[#2A9D8F]" /> : <Share2 className="w-4 h-4" />}
              </button>

              <button
                type="button"
                onClick={() => toggleFavorite(product.id)}
                aria-label={favorited ? 'Remove from favorites' : 'Add to favorites'}
                className={`w-10 h-10 rounded-full flex items-center justify-center shadow-md backdrop-blur-md transition-all active:scale-90 ${
                  favorited
                    ? 'bg-[#D62828] text-white'
                    : 'bg-white/90 text-gray-700 hover:bg-white hover:text-[#D62828]'
                }`}
              >
                <Heart className={`w-5 h-5 ${favorited ? 'fill-current' : ''}`} />
              </button>
            </div>

            {/* Serves Tag bottom left */}
            <div className="absolute bottom-4 left-4 bg-black/60 backdrop-blur-xs text-white text-xs px-3 py-1.5 rounded-full flex items-center gap-2">
              <Users className="w-3.5 h-3.5 text-[#FCBF49]" />
              <span>Serves: {product.serves || '1-2 persons'}</span>
            </div>
          </div>

          {/* Right Column: Product Info & Actions */}
          <div className="lg:col-span-6 p-6 sm:p-8 lg:p-10 flex flex-col justify-between">
            <div>
              {/* Category & Prep Time */}
              <div className="flex items-center justify-between gap-2 mb-2">
                <span className="text-xs font-black uppercase tracking-widest text-[#F77F00]">
                  {product.category}
                </span>
                {product.prepTime && (
                  <span className="text-xs font-semibold text-gray-500 flex items-center gap-1">
                    <Clock className="w-3.5 h-3.5 text-gray-400" />
                    <span>{product.prepTime} prep</span>
                  </span>
                )}
              </div>

              {/* Title */}
              <h1 className="text-2xl sm:text-3xl lg:text-4xl font-black text-[#1F1F1F] font-display">
                {product.name}
              </h1>

              {/* Rating & Reviews */}
              <div className="mt-3 flex items-center gap-4">
                <Rating rating={product.rating} reviewsCount={product.reviewsCount} size="md" />
                <span className="text-xs text-gray-400">|</span>
                <span className="text-xs font-semibold text-[#2A9D8F] flex items-center gap-1">
                  <ShieldCheck className="w-3.5 h-3.5" />
                  100% Halal
                </span>
              </div>

              {/* Price Row */}
              <div className="mt-5 p-4 rounded-2xl bg-[#FFF8EF] border border-[#FCBF49]/30 flex items-baseline gap-3">
                <span className="text-3xl font-black text-[#D62828]">
                  {RESTAURANT_INFO.currency} {product.price.toLocaleString()}
                </span>
                {product.oldPrice && (
                  <span className="text-sm text-gray-400 line-through font-medium">
                    {RESTAURANT_INFO.currency} {product.oldPrice.toLocaleString()}
                  </span>
                )}
                {product.discount && (
                  <span className="ml-auto text-xs font-black text-[#F77F00] bg-white px-2.5 py-1 rounded-lg border border-[#FCBF49]/40">
                    Save {RESTAURANT_INFO.currency} {(product.oldPrice! - product.price).toLocaleString()}
                  </span>
                )}
              </div>

              {/* Description */}
              <div className="mt-5">
                <h3 className="text-xs font-bold text-gray-500 uppercase tracking-wider mb-1.5">
                  About this Dish
                </h3>
                <p className="text-sm sm:text-base text-gray-700 leading-relaxed">
                  {product.description}
                </p>
              </div>

              {/* Tags / Ingredients */}
              {product.tags && product.tags.length > 0 && (
                <div className="mt-4 flex flex-wrap gap-2">
                  {product.tags.map((tag) => (
                    <span
                      key={tag}
                      className="px-2.5 py-1 rounded-lg bg-gray-100 text-gray-600 text-xs font-semibold"
                    >
                      #{tag}
                    </span>
                  ))}
                </div>
              )}

              {/* Special Instructions Input */}
              <div className="mt-6">
                <label
                  htmlFor="special-instructions"
                  className="block text-xs font-bold text-gray-700 mb-1.5"
                >
                  Special Cooking Request (Optional):
                </label>
                <input
                  type="text"
                  id="special-instructions"
                  value={specialNotes}
                  onChange={(e) => setSpecialNotes(e.target.value)}
                  placeholder="e.g. Extra raita, less spicy, no onions, extra dip"
                  className="w-full px-4 py-2.5 text-xs rounded-xl border border-gray-200 focus:outline-none focus:border-[#F77F00] focus:ring-2 focus:ring-[#F77F00]/20"
                />
              </div>
            </div>

            {/* Bottom Action Area: Quantity & Add to Cart */}
            <div className="mt-8 pt-6 border-t border-gray-100 flex flex-col sm:flex-row items-center gap-4">
              <div className="flex items-center gap-3 w-full sm:w-auto justify-between sm:justify-start">
                <span className="text-xs font-bold text-gray-600">Quantity:</span>
                <QuantitySelector
                  quantity={quantity}
                  onIncrease={() => setQuantity((q) => q + 1)}
                  onDecrease={() => setQuantity((q) => Math.max(1, q - 1))}
                  size="lg"
                />
              </div>

              <div className="flex items-center gap-2 w-full sm:flex-1">
                <button
                  type="button"
                  id="product-detail-add-to-cart-btn"
                  onClick={handleAddToCart}
                  className="flex-1 py-4 px-6 rounded-2xl bg-gradient-to-r from-[#F77F00] to-[#E06F00] hover:from-[#E06F00] hover:to-[#D62828] text-white font-extrabold text-sm sm:text-base shadow-lg shadow-[#F77F00]/30 transition-all flex items-center justify-center gap-2 active:scale-98 cursor-pointer"
                >
                  <ShoppingBag className="w-5 h-5" />
                  <span>
                    Add to Cart • {RESTAURANT_INFO.currency} {(product.price * quantity).toLocaleString()}
                  </span>
                </button>

                <a
                  href={getWhatsAppUrl(whatsappMessage)}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="p-4 rounded-2xl bg-[#25D366] text-white hover:bg-[#20bd5a] shadow-md transition-all shrink-0"
                  title="Ask on WhatsApp"
                >
                  <MessageCircle className="w-5 h-5 fill-white" />
                </a>
              </div>
            </div>

          </div>

        </div>

        {/* Related Products Carousel */}
        {relatedProducts.length > 0 && (
          <div className="mt-16 sm:mt-20">
            <div className="flex items-center justify-between mb-8">
              <div>
                <h3 className="text-2xl sm:text-3xl font-black text-[#1F1F1F] font-display">
                  You Might Also Crave
                </h3>
                <p className="text-xs sm:text-sm text-gray-500 mt-1">
                  Popular recommendations from the {product.category} section
                </p>
              </div>

              <Link
                to={`/menu?category=${encodeURIComponent(product.category)}`}
                className="text-xs font-bold text-[#D62828] hover:underline"
              >
                View all {product.category}
              </Link>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {relatedProducts.map((rel) => (
                <ProductCard key={rel.id} product={rel} />
              ))}
            </div>
          </div>
        )}

      </div>
    </div>
  );
};
