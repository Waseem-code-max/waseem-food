import React, { useState, useEffect, useMemo } from 'react';
import { useSearchParams } from 'react-router-dom';
import { SlidersHorizontal, ArrowUpDown, UtensilsCrossed, RefreshCw } from 'lucide-react';
import { CategoryList } from '../components/CategoryList';
import { ProductGrid } from '../components/ProductGrid';
import { SearchBar } from '../components/SearchBar';
import { Breadcrumb } from '../components/Breadcrumb';
import { getProducts } from '../services/api';
import { Product } from '../types';
import { RESTAURANT_INFO } from '../config/restaurant';

export const MenuPage: React.FC = () => {
  const [searchParams, setSearchParams] = useSearchParams();
  const [products, setProducts] = useState<Product[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  const initialCat = searchParams.get('category') || 'All';
  const initialSearch = searchParams.get('search') || '';

  const [selectedCategory, setSelectedCategory] = useState<string>(initialCat);
  const [searchQuery, setSearchQuery] = useState<string>(initialSearch);
  const [sortBy, setSortBy] = useState<'popular' | 'price-asc' | 'price-desc' | 'rating'>('popular');

  useEffect(() => {
    window.scrollTo(0, 0);
    document.title = `Full Menu | ${RESTAURANT_INFO.name}`;

    async function loadData() {
      setIsLoading(true);
      const data = await getProducts();
      setProducts(data);
      setIsLoading(false);
    }
    loadData();
  }, []);

  // Update URL search query params when category changes
  const handleSelectCategory = (cat: string) => {
    setSelectedCategory(cat);
    if (cat.toLowerCase() === 'all') {
      searchParams.delete('category');
    } else {
      searchParams.set('category', cat);
    }
    setSearchParams(searchParams);
  };

  // Filter and sort products
  const processedProducts = useMemo(() => {
    let result = [...products];

    // Filter by Category
    if (selectedCategory.toLowerCase() !== 'all') {
      result = result.filter(
        (p) => p.category.toLowerCase() === selectedCategory.toLowerCase()
      );
    }

    // Filter by Search Query
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase().trim();
      result = result.filter(
        (p) =>
          p.name.toLowerCase().includes(q) ||
          p.category.toLowerCase().includes(q) ||
          p.description.toLowerCase().includes(q)
      );
    }

    // Sort
    switch (sortBy) {
      case 'price-asc':
        result.sort((a, b) => a.price - b.price);
        break;
      case 'price-desc':
        result.sort((a, b) => b.price - a.price);
        break;
      case 'rating':
        result.sort((a, b) => b.rating - a.rating);
        break;
      case 'popular':
      default:
        result.sort((a, b) => (b.featured ? 1 : 0) - (a.featured ? 1 : 0));
        break;
    }

    return result;
  }, [products, selectedCategory, searchQuery, sortBy]);

  // Category counts
  const categoryCounts = useMemo(() => {
    const counts: Record<string, number> = { All: products.length };
    products.forEach((p) => {
      counts[p.category] = (counts[p.category] || 0) + 1;
    });
    return counts;
  }, [products]);

  const handleResetFilters = () => {
    setSelectedCategory('All');
    setSearchQuery('');
    setSortBy('popular');
    setSearchParams({});
  };

  return (
    <div className="min-h-screen bg-[#FFF8EF] py-8 sm:py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Breadcrumb */}
        <Breadcrumb items={[{ label: 'Our Menu' }]} />

        {/* Page Header */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mt-2 mb-8">
          <div>
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#FFECEC] text-[#D62828] text-xs font-black uppercase tracking-wider mb-2">
              <UtensilsCrossed className="w-3.5 h-3.5" />
              <span>Authentic Pakistani Flavors</span>
            </div>
            <h1 className="text-3xl sm:text-4xl lg:text-5xl font-black text-[#1F1F1F] font-display tracking-tight">
              Waseem Food Menu
            </h1>
            <p className="text-gray-600 text-sm mt-1.5">
              Explore our selection of biryani, karahi, sizzling BBQ, crispy burgers, and combos.
            </p>
          </div>

          {/* Search bar in header */}
          <div className="w-full md:w-80">
            <SearchBar
              initialQuery={searchQuery}
              onSearch={(q) => setSearchQuery(q)}
              showDropdown={false}
              placeholder="Search dishes..."
            />
          </div>
        </div>

        {/* Horizontal Category Carousel */}
        <div className="mb-8 bg-white p-4 rounded-3xl border border-gray-100 shadow-2xs">
          <CategoryList
            activeCategory={selectedCategory}
            onSelectCategory={handleSelectCategory}
            itemCounts={categoryCounts}
          />
        </div>

        {/* Filters and Sorting Toolbar */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 mb-6 border-b border-gray-200/60">
          <div className="flex items-center gap-2 text-xs sm:text-sm text-gray-600">
            <SlidersHorizontal className="w-4 h-4 text-[#F77F00]" />
            <span>
              Showing <strong className="text-[#1F1F1F]">{processedProducts.length}</strong> delicious items
            </span>
            {(selectedCategory !== 'All' || searchQuery) && (
              <button
                type="button"
                onClick={handleResetFilters}
                className="ml-3 text-xs font-bold text-[#D62828] hover:underline flex items-center gap-1"
              >
                <RefreshCw className="w-3 h-3" />
                <span>Reset Filters</span>
              </button>
            )}
          </div>

          {/* Sort Dropdown */}
          <div className="flex items-center gap-2 self-end sm:self-auto">
            <ArrowUpDown className="w-4 h-4 text-gray-400" />
            <label htmlFor="sort-dropdown" className="text-xs font-bold text-gray-700">
              Sort by:
            </label>
            <select
              id="sort-dropdown"
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as any)}
              className="bg-white border border-gray-200 text-xs font-bold text-[#1F1F1F] rounded-xl px-3 py-2 shadow-2xs focus:outline-none focus:border-[#F77F00]"
            >
              <option value="popular">Popular First</option>
              <option value="price-asc">Price: Low to High</option>
              <option value="price-desc">Price: High to Low</option>
              <option value="rating">Highest Rated</option>
            </select>
          </div>
        </div>

        {/* Products Grid */}
        {isLoading ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
            {[1, 2, 3, 4, 5, 6, 7, 8].map((n) => (
              <div key={n} className="h-72 bg-white rounded-2xl animate-pulse" />
            ))}
          </div>
        ) : (
          <ProductGrid
            products={processedProducts}
            emptyMessage={
              searchQuery
                ? `No food items found for "${searchQuery}"`
                : `No items in ${selectedCategory} category.`
            }
            emptySubtitle="Try searching for something else or reset your category filter."
          />
        )}

      </div>
    </div>
  );
};
