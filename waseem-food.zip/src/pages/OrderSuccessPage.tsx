import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import {
  CheckCircle2,
  ShoppingBag,
  Home,
  MessageCircle,
  Clock,
  MapPin,
  Sparkles,
  Printer,
} from 'lucide-react';
import { getLatestOrder } from '../services/api';
import { Order } from '../types';
import { RESTAURANT_INFO, getWhatsAppUrl } from '../config/restaurant';

export const OrderSuccessPage: React.FC = () => {
  const [order, setOrder] = useState<Order | null>(null);

  useEffect(() => {
    window.scrollTo(0, 0);
    document.title = `Order Placed Successfully! | ${RESTAURANT_INFO.name}`;

    async function load() {
      const latest = await getLatestOrder();
      setOrder(latest);
    }
    load();
  }, []);

  // Format pre-filled WhatsApp message with order details
  const whatsappOrderMessage = order
    ? `Hello ${RESTAURANT_INFO.name}, I placed Order *#${order.orderId}* on your website for Rs. ${order.total.toLocaleString()}. Please confirm preparation and delivery status. Thank you!`
    : `Hello ${RESTAURANT_INFO.name}, I just placed an order on your website. Please confirm!`;

  return (
    <div className="min-h-screen bg-[#FFF8EF] py-10 sm:py-16">
      <div className="max-w-3xl mx-auto px-4 sm:px-6">
        
        {/* Celebration Header Card */}
        <div className="bg-white rounded-3xl border border-gray-100 shadow-xl p-6 sm:p-10 text-center relative overflow-hidden">
          {/* Decorative Confetti Circles */}
          <div className="absolute -top-12 -right-12 w-36 h-36 bg-[#FCBF49]/20 rounded-full blur-xl" />
          <div className="absolute -bottom-12 -left-12 w-36 h-36 bg-[#D62828]/10 rounded-full blur-xl" />

          <div className="w-20 h-20 rounded-full bg-gradient-to-tr from-[#2A9D8F] to-[#48cae4] text-white flex items-center justify-center mx-auto mb-5 shadow-lg shadow-[#2A9D8F]/30 animate-bounce">
            <CheckCircle2 className="w-10 h-10 stroke-[2.5]" />
          </div>

          <span className="inline-flex items-center gap-1.5 px-3.5 py-1 rounded-full bg-[#FFECEC] text-[#D62828] text-xs font-black uppercase tracking-wider mb-2">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Order Confirmed</span>
          </span>

          <h1 className="text-3xl sm:text-4xl font-black text-[#1F1F1F] font-display">
            Order Placed Successfully!
          </h1>

          <p className="text-lg font-black text-[#D62828] mt-2">
            Order #{order ? order.orderId : 'WF-10001'}
          </p>

          <p className="text-sm sm:text-base text-gray-600 max-w-md mx-auto mt-2 leading-relaxed">
            Thank you for ordering from <strong>{RESTAURANT_INFO.name}</strong>. Our kitchen has received your order and our chefs are preparing it fresh right now.
          </p>

          {/* Delivery ETA pill */}
          <div className="mt-6 inline-flex items-center gap-2 px-5 py-2.5 rounded-2xl bg-[#FFF8EF] border border-[#FCBF49]/40 text-xs font-bold text-[#1F1F1F]">
            <Clock className="w-4 h-4 text-[#F77F00]" />
            <span>Estimated Delivery Time: <strong>30 - 45 Minutes</strong></span>
          </div>

          {/* Itemized Order Details */}
          {order && (
            <div className="mt-8 pt-8 border-t border-gray-100 text-left">
              <h3 className="text-sm font-black uppercase tracking-wider text-gray-400 mb-4">
                Order Summary &amp; Receipt
              </h3>

              <div className="divide-y divide-gray-100 bg-[#FFF8EF]/50 rounded-2xl p-4 border border-[#FCBF49]/20">
                {order.items.map((item, idx) => (
                  <div key={idx} className="py-2.5 flex items-center justify-between text-xs sm:text-sm">
                    <div className="flex items-center gap-2.5">
                      <img
                        src={item.image}
                        alt={item.name}
                        className="w-9 h-9 rounded-lg object-cover"
                      />
                      <div>
                        <span className="font-bold text-[#1F1F1F]">{item.name}</span>
                        <span className="text-gray-500 text-xs block">
                          Qty: {item.quantity}
                        </span>
                      </div>
                    </div>
                    <span className="font-extrabold text-[#1F1F1F]">
                      {RESTAURANT_INFO.currency} {(item.price * item.quantity).toLocaleString()}
                    </span>
                  </div>
                ))}

                <div className="pt-3 mt-2 border-t border-gray-200 text-xs space-y-1">
                  <div className="flex justify-between text-gray-600">
                    <span>Subtotal:</span>
                    <span>{RESTAURANT_INFO.currency} {order.subtotal.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between text-gray-600">
                    <span>Delivery:</span>
                    <span>
                      {order.deliveryFee === 0
                        ? 'FREE'
                        : `${RESTAURANT_INFO.currency} ${order.deliveryFee.toLocaleString()}`}
                    </span>
                  </div>
                  <div className="flex justify-between font-black text-sm text-[#D62828] pt-1">
                    <span>Grand Total:</span>
                    <span>{RESTAURANT_INFO.currency} {order.total.toLocaleString()}</span>
                  </div>
                </div>
              </div>

              {/* Delivery and Payment Details */}
              <div className="mt-6 grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                <div className="p-4 rounded-2xl bg-gray-50 border border-gray-100">
                  <span className="font-bold text-gray-400 uppercase tracking-wider block mb-1">
                    Delivering To:
                  </span>
                  <p className="font-bold text-[#1F1F1F]">{order.customer.fullName}</p>
                  <p className="text-gray-600 mt-0.5">{order.customer.phone}</p>
                  <p className="text-gray-600 mt-0.5 leading-snug">
                    {order.customer.address}, {order.customer.city}
                  </p>
                </div>

                <div className="p-4 rounded-2xl bg-gray-50 border border-gray-100">
                  <span className="font-bold text-gray-400 uppercase tracking-wider block mb-1">
                    Payment Method:
                  </span>
                  <p className="font-bold text-[#1F1F1F] uppercase">
                    {order.paymentMethod.replace('_', ' ')}
                  </p>
                  <p className="text-gray-500 mt-1">
                    Please keep exact cash ready upon rider arrival if paying COD.
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* Action Buttons */}
          <div className="mt-8 flex flex-col sm:flex-row items-center justify-center gap-3">
            <a
              href={getWhatsAppUrl(whatsappOrderMessage)}
              target="_blank"
              rel="noopener noreferrer"
              id="success-whatsapp-btn"
              className="w-full sm:w-auto px-6 py-3.5 rounded-2xl bg-[#25D366] hover:bg-[#20bd5a] text-white font-black text-xs sm:text-sm shadow-md flex items-center justify-center gap-2 active:scale-95 transition-all"
            >
              <MessageCircle className="w-4 h-4" />
              <span>Track or Update on WhatsApp</span>
            </a>

            <Link
              to="/menu"
              className="w-full sm:w-auto px-6 py-3.5 rounded-2xl bg-[#F77F00] hover:bg-[#E06F00] text-white font-black text-xs sm:text-sm shadow-md flex items-center justify-center gap-2 active:scale-95 transition-all"
            >
              <ShoppingBag className="w-4 h-4" />
              <span>Continue Shopping</span>
            </Link>

            <Link
              to="/"
              className="w-full sm:w-auto px-6 py-3.5 rounded-2xl bg-gray-100 hover:bg-gray-200 text-gray-700 font-bold text-xs sm:text-sm flex items-center justify-center gap-2 transition-all"
            >
              <Home className="w-4 h-4" />
              <span>Back to Home</span>
            </Link>
          </div>

        </div>

      </div>
    </div>
  );
};
