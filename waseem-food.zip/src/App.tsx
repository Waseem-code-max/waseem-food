import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { CartProvider } from './context/CartContext';
import { Header } from './components/Header';
import { Footer } from './components/Footer';
import { CartDrawer } from './components/CartDrawer';
import { FloatingWhatsAppButton } from './components/FloatingWhatsAppButton';
import { Toast } from './components/Toast';
import { HomePage } from './pages/HomePage';
import { MenuPage } from './pages/MenuPage';
import { ProductDetailsPage } from './pages/ProductDetailsPage';
import { DealsPage } from './pages/DealsPage';
import { AboutPage } from './pages/AboutPage';
import { ContactPage } from './pages/ContactPage';
import { CheckoutPage } from './pages/CheckoutPage';
import { OrderSuccessPage } from './pages/OrderSuccessPage';

export default function App() {
  return (
    <CartProvider>
      <BrowserRouter>
        <div className="min-h-screen flex flex-col bg-[#FFF8EF] font-sans antialiased text-[#1F1F1F] selection:bg-[#FCBF49] selection:text-[#1F1F1F]">
          {/* Global Sticky Header */}
          <Header />

          {/* Main Routing Content */}
          <main className="flex-1">
            <Routes>
              <Route path="/" element={<HomePage />} />
              <Route path="/menu" element={<MenuPage />} />
              <Route path="/product/:slug" element={<ProductDetailsPage />} />
              <Route path="/deals" element={<DealsPage />} />
              <Route path="/about" element={<AboutPage />} />
              <Route path="/contact" element={<ContactPage />} />
              <Route path="/checkout" element={<CheckoutPage />} />
              <Route path="/order-success" element={<OrderSuccessPage />} />
              <Route path="*" element={<Navigate to="/" replace />} />
            </Routes>
          </main>

          {/* Global 4-Column Footer */}
          <Footer />

          {/* Sliding Cart Drawer */}
          <CartDrawer />

          {/* Floating WhatsApp Order Button */}
          <FloatingWhatsAppButton />

          {/* Toast Notification Container */}
          <Toast />
        </div>
      </BrowserRouter>
    </CartProvider>
  );
}
