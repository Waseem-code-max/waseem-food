import { RestaurantInfo } from '../types';

export const RESTAURANT_INFO: RestaurantInfo = {
  name: "Waseem Food",
  legalName: "Waseem Food Restaurants PVT Ltd.",
  domain: "waseemfood.com",
  tagline: "Delicious Food, Made Fresh",
  subtitle: "Hot, fresh and delicious meals delivered straight to your door.",
  phone: "+92 300 1234567",
  displayPhone: "0300-1234567",
  // Central WhatsApp number in international format for wa.me links
  whatsappNumber: "+923001234567",
  whatsappDisplay: "+92 300 1234567",
  email: "info@waseemfood.com",
  ordersEmail: "orders@waseemfood.com",
  address: "Shop #14, Main Boulevard, Gulberg III, Lahore, Punjab, Pakistan",
  city: "Lahore",
  coordinates: {
    lat: 31.5204,
    lng: 74.3587,
  },
  openingHours: "11:00 AM - 02:00 AM (Monday - Sunday)",
  currency: "Rs.",
  currencySymbol: "Rs.",
  standardDeliveryFee: 150,
  freeDeliveryThreshold: 2500,
  socials: {
    facebook: "https://facebook.com/waseemfoodpk",
    instagram: "https://instagram.com/waseemfoodpk",
    tiktok: "https://tiktok.com/@waseemfoodpk",
    youtube: "https://youtube.com/@waseemfoodpk",
  },
};

export const CITIES_SERVED = [
  "Lahore",
  "Islamabad",
  "Rawalpindi",
  "Karachi",
  "Faisalabad"
];

/**
 * Generates an active WhatsApp order/inquiry link
 */
export function getWhatsAppUrl(customMessage?: string): string {
  const cleanNumber = RESTAURANT_INFO.whatsappNumber.replace(/[^0-9]/g, '');
  const message = customMessage || `Hello Waseem Food, I would like to place an order!`;
  return `https://wa.me/${cleanNumber}?text=${encodeURIComponent(message)}`;
}
