import { Category } from '../types';

export const CATEGORIES: Category[] = [
  { id: 'all', name: 'All', slug: 'all', iconName: 'UtensilsCrossed', description: 'Explore our full mouth-watering menu' },
  { id: 'biryani', name: 'Biryani', slug: 'biryani', iconName: 'Flame', description: 'Fragrant basmati rice cooked with authentic spices' },
  { id: 'burgers', name: 'Burgers', slug: 'burgers', iconName: 'Sandwich', description: 'Crispy zinger fillets and juicy grilled patties' },
  { id: 'pizza', name: 'Pizza', slug: 'pizza', iconName: 'Pizza', description: 'Fresh dough with loaded cheese and spicy chicken toppings' },
  { id: 'chicken', name: 'Chicken', slug: 'chicken', iconName: 'Drumstick', description: 'Traditional Karahis, Handis and broast' },
  { id: 'bbq', name: 'BBQ', slug: 'bbq', iconName: 'FlameKindling', description: 'Charcoal grilled seekh kababs, tikka and malai boti' },
  { id: 'rice', name: 'Rice', slug: 'rice', iconName: 'Wheat', description: 'Fried rice, pulao and aromatic grain platters' },
  { id: 'sandwiches', name: 'Sandwiches', slug: 'sandwiches', iconName: 'Layers', description: 'Triple-decker club sandwiches with egg and chicken' },
  { id: 'fries', name: 'Fries', slug: 'fries', iconName: 'Sparkles', description: 'Crispy golden fries, loaded mayo garlic and cheese' },
  { id: 'drinks', name: 'Drinks', slug: 'drinks', iconName: 'CupSoda', description: 'Chilled soft drinks, fresh lime and mint margaritas' },
  { id: 'desserts', name: 'Desserts', slug: 'desserts', iconName: 'Cake', description: 'Hot Gulab Jamun, traditional Kheer and Kulfi' },
  { id: 'deals', name: 'Deals', slug: 'deals', iconName: 'Tag', description: 'Budget-friendly family combos and value boxes' },
];
