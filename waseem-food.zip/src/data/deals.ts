import { Deal } from '../types';

export const DEALS: Deal[] = [
  {
    id: 'deal-family',
    name: "Waseem Family Deal",
    slug: "waseem-family-deal",
    description: "The ultimate fast-food combo for family and friends. Crispy zingers paired with loaded fries and chilled drinks.",
    includedItems: [
      "2 Crispy Zinger Burgers",
      "2 Regular Golden Fries",
      "2 Chilled Cold Drinks (330ml)",
      "Special Dip Sauce"
    ],
    price: 1499,
    oldPrice: 1900,
    discount: 21,
    image: "https://images.unsplash.com/photo-1594212699903-ec8a3eca50f5?auto=format&fit=crop&w=900&q=80",
    badge: "Most Popular",
    serves: "2-3 Persons",
    available: true
  },
  {
    id: 'deal-biryani-feast',
    name: "Biryani Feast Combo",
    slug: "biryani-feast-combo",
    description: "Authentic Pakistani comfort food feast with two hearty servings of Chicken Biryani, cooling raita, fresh salad, drinks and sweet Gulab Jamun.",
    includedItems: [
      "2 Special Chicken Biryani Plates",
      "1 Mint Zeera Raita & Kachumber Salad",
      "2 Chilled Cold Drinks",
      "2 Hot Shahi Gulab Jamun"
    ],
    price: 1199,
    oldPrice: 1550,
    discount: 23,
    image: "https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?auto=format&fit=crop&w=900&q=80",
    badge: "Save Rs. 351",
    serves: "2 Persons",
    available: true
  },
  {
    id: 'deal-bbq-bonanza',
    name: "Mega BBQ Bonanza",
    slug: "mega-bbq-bonanza",
    description: "A charcoal-grilled delight featuring aromatic tikka, tender juicy seekh kababs, fluffy roghani naans and a large family bottle.",
    includedItems: [
      "1 Chicken Tikka Quarter (Chest/Leg)",
      "4 Juicy Chicken Seekh Kababs",
      "4 Piping Hot Roghani Naans",
      "Mint Raita & Onion Salad",
      "1.5 Liter Chilled Soft Drink"
    ],
    price: 2199,
    oldPrice: 2750,
    discount: 20,
    image: "https://images.unsplash.com/photo-1555939594-58d7cb561ad1?auto=format&fit=crop&w=900&q=80",
    badge: "Weekend Special",
    serves: "3-4 Persons",
    available: true
  },
  {
    id: 'deal-midnight-craver',
    name: "Midnight Zinger Craver",
    slug: "midnight-zinger-craver",
    description: "Late night cravings sorted! Crisp zinger, garlic mayo fries and a chilled soda.",
    includedItems: [
      "1 Crispy Jumbo Zinger Burger",
      "1 Mayo Garlic Fries",
      "1 Cold Drink Can (330ml)"
    ],
    price: 799,
    oldPrice: 990,
    discount: 19,
    image: "https://images.unsplash.com/photo-1568901346375-23c9450c58cd?auto=format&fit=crop&w=900&q=80",
    badge: "Solo Value",
    serves: "1 Person",
    available: true
  },
  {
    id: 'deal-pizza-party',
    name: "Mega Pizza Party",
    slug: "mega-pizza-party",
    description: "Two large signature pizzas of your choice with cheesy garlic bread and a family drink.",
    includedItems: [
      "2 Large Pizzas (Tikka or Fajita)",
      "1 Cheesy Garlic Bread (4 Pcs)",
      "1.5 Liter Chilled Drink"
    ],
    price: 2499,
    oldPrice: 3100,
    discount: 19,
    image: "https://images.unsplash.com/photo-1513104890138-7c749659a591?auto=format&fit=crop&w=900&q=80",
    badge: "Big Group",
    serves: "4-5 Persons",
    available: true
  }
];
