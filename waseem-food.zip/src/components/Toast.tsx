import React from 'react';
import { CheckCircle2, ShoppingBag, X } from 'lucide-react';
import { useCart } from '../context/CartContext';

export const Toast: React.FC = () => {
  const { toast, hideToast, openCart } = useCart();

  if (!toast) return null;

  return (
    <div
      role="status"
      aria-live="polite"
      className="fixed bottom-20 sm:bottom-6 left-1/2 -translate-x-1/2 z-50 flex items-center gap-3 px-4 py-3 rounded-2xl bg-[#1F1F1F] text-white shadow-2xl border border-white/10 max-w-[90vw] sm:max-w-md"
    >
      <div className="w-8 h-8 rounded-full bg-[#D62828] flex items-center justify-center text-white shrink-0">
        <CheckCircle2 className="w-4 h-4 text-[#FCBF49]" />
      </div>

      <div className="flex-1 text-sm font-medium pr-1">
        {toast.message}
      </div>

      <button
        type="button"
        onClick={openCart}
        className="text-xs font-bold text-[#FCBF49] hover:underline flex items-center gap-1 shrink-0 bg-white/10 px-2.5 py-1.5 rounded-lg hover:bg-white/20 transition-colors"
      >
        <ShoppingBag className="w-3.5 h-3.5" />
        <span>View Cart</span>
      </button>

      <button
        type="button"
        onClick={hideToast}
        className="text-gray-400 hover:text-white p-1 rounded-md"
        aria-label="Dismiss notification"
      >
        <X className="w-4 h-4" />
      </button>
    </div>
  );
};
