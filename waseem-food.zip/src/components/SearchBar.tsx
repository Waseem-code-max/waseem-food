import React, { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { Search, X, ArrowRight, Sparkles } from 'lucide-react';
import { Product } from '../types';
import { searchProducts } from '../services/api';
import { RESTAURANT_INFO } from '../config/restaurant';

interface SearchBarProps {
  initialQuery?: string;
  onSearch?: (query: string) => void;
  placeholder?: string;
  showDropdown?: boolean;
  className?: string;
}

export const SearchBar: React.FC<SearchBarProps> = ({
  initialQuery = '',
  onSearch,
  placeholder = 'Search biryani, zinger, karahi, pizza, deals...',
  showDropdown = true,
  className = '',
}) => {
  const [query, setQuery] = useState(initialQuery);
  const [results, setResults] = useState<Product[]>([]);
  const [isSearching, setIsSearching] = useState(false);
  const [isOpen, setIsOpen] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);
  const navigate = useNavigate();

  useEffect(() => {
    setQuery(initialQuery);
  }, [initialQuery]);

  useEffect(() => {
    const handleOutsideClick = (e: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleOutsideClick);
    return () => document.removeEventListener('mousedown', handleOutsideClick);
  }, []);

  useEffect(() => {
    if (!query.trim()) {
      setResults([]);
      setIsSearching(false);
      if (onSearch) onSearch('');
      return;
    }

    setIsSearching(true);
    const timer = setTimeout(async () => {
      const hits = await searchProducts(query);
      setResults(hits);
      setIsSearching(false);
      if (showDropdown && hits.length >= 0) {
        setIsOpen(true);
      }
      if (onSearch) onSearch(query);
    }, 150);

    return () => clearTimeout(timer);
  }, [query, onSearch, showDropdown]);

  const handleClear = () => {
    setQuery('');
    setResults([]);
    setIsOpen(false);
    if (onSearch) onSearch('');
  };

  const handleSelectProduct = (slug: string) => {
    setIsOpen(false);
    navigate(`/product/${slug}`);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (query.trim()) {
      setIsOpen(false);
      navigate(`/menu?search=${encodeURIComponent(query.trim())}`);
    }
  };

  return (
    <div ref={containerRef} className={`relative w-full ${className}`}>
      <form onSubmit={handleSubmit} className="relative flex items-center">
        <Search className="w-5 h-5 text-gray-400 absolute left-4 pointer-events-none" />
        
        <input
          type="text"
          id="search-input"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          onFocus={() => {
            if (query.trim() && showDropdown) setIsOpen(true);
          }}
          placeholder={placeholder}
          className="w-full pl-11 pr-10 py-3 rounded-full bg-white border border-gray-200 text-sm text-[#1F1F1F] placeholder-gray-400 shadow-xs focus:outline-none focus:border-[#F77F00] focus:ring-3 focus:ring-[#F77F00]/15 transition-all"
        />

        {query && (
          <button
            type="button"
            onClick={handleClear}
            className="absolute right-3.5 p-1 rounded-full text-gray-400 hover:text-[#D62828] hover:bg-gray-100 transition-colors"
            title="Clear search"
          >
            <X className="w-4 h-4" />
          </button>
        )}
      </form>

      {/* Quick Search Dropdown Preview */}
      {showDropdown && isOpen && query.trim().length > 0 && (
        <div className="absolute top-full left-0 right-0 mt-2 bg-white rounded-2xl shadow-xl border border-gray-100 overflow-hidden z-50 max-h-[380px] overflow-y-auto">
          <div className="p-3 bg-[#FFF8EF] border-b border-[#FCBF49]/30 flex items-center justify-between text-xs">
            <span className="font-semibold text-gray-700">
              Search results for: &ldquo;<span className="text-[#D62828] font-bold">{query}</span>&rdquo;
            </span>
            <span className="text-gray-500 font-medium">
              {results.length} item{results.length !== 1 ? 's' : ''} found
            </span>
          </div>

          {isSearching ? (
            <div className="p-8 text-center text-sm text-gray-400">
              Searching fresh menu...
            </div>
          ) : results.length === 0 ? (
            <div className="p-8 text-center">
              <p className="text-sm font-semibold text-gray-700">No food items found.</p>
              <p className="text-xs text-gray-500 mt-1">
                Try searching for &quot;Biryani&quot;, &quot;Zinger&quot;, &quot;Karahi&quot;, or &quot;Deals&quot;.
              </p>
            </div>
          ) : (
            <div className="divide-y divide-gray-50">
              {results.slice(0, 6).map((product) => (
                <button
                  key={product.id}
                  type="button"
                  onClick={() => handleSelectProduct(product.slug)}
                  className="w-full px-4 py-3 text-left flex items-center gap-3 hover:bg-[#FFF8EF]/60 transition-colors group"
                >
                  <img
                    src={product.image}
                    alt={product.name}
                    className="w-12 h-12 rounded-xl object-cover shrink-0 border border-gray-100 group-hover:scale-105 transition-transform"
                    loading="lazy"
                  />
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between gap-2">
                      <h4 className="text-sm font-bold text-[#1F1F1F] group-hover:text-[#D62828] truncate transition-colors">
                        {product.name}
                      </h4>
                      <span className="text-xs font-extrabold text-[#D62828] shrink-0">
                        {RESTAURANT_INFO.currency} {product.price.toLocaleString()}
                      </span>
                    </div>
                    <p className="text-xs text-gray-500 truncate mt-0.5">
                      {product.category} • {product.description}
                    </p>
                  </div>
                </button>
              ))}

              {results.length > 6 && (
                <button
                  type="button"
                  onClick={handleSubmit}
                  className="w-full py-2.5 px-4 text-center text-xs font-bold text-[#D62828] bg-[#FFF8EF] hover:bg-[#FFECEC] flex items-center justify-center gap-1.5 transition-colors"
                >
                  <span>View all {results.length} results</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              )}
            </div>
          )}

          {/* Quick Category Suggestions */}
          <div className="p-3 bg-gray-50 border-t border-gray-100 flex items-center gap-2 flex-wrap text-xs">
            <span className="text-gray-400 flex items-center gap-1">
              <Sparkles className="w-3 h-3 text-[#F77F00]" /> Popular:
            </span>
            {['Biryani', 'Zinger', 'Karahi', 'Pizza', 'BBQ'].map((term) => (
              <button
                key={term}
                type="button"
                onClick={() => setQuery(term)}
                className="px-2.5 py-0.5 rounded-full bg-white border border-gray-200 text-gray-600 hover:text-[#D62828] hover:border-[#D62828] text-xs transition-colors"
              >
                {term}
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
