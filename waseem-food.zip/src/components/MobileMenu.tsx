import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import {
  X,
  Home,
  UtensilsCrossed,
  Tag,
  Info,
  PhoneCall,
  ShoppingBag,
  MessageCircle,
  Clock,
  MapPin,
} from 'lucide-react';
import { Logo } from './Logo';
import { RESTAURANT_INFO, getWhatsAppUrl } from '../config/restaurant';

interface MobileMenuProps {
  isOpen: boolean;
  onClose: () => void;
  onOpenSearch: () => void;
}

export const MobileMenu: React.FC<MobileMenuProps> = ({
  isOpen,
  onClose,
  onOpenSearch,
}) => {
  const location = useLocation();

  if (!isOpen) return null;

  const navLinks = [
    { label: 'Home', path: '/', icon: Home },
    { label: 'Menu', path: '/menu', icon: UtensilsCrossed },
    { label: 'Deals', path: '/deals', icon: Tag, badge: 'Offers' },
    { label: 'About', path: '/about', icon: Info },
    { label: 'Contact', path: '/contact', icon: PhoneCall },
  ];

  return (
    <div className="fixed inset-0 z-50 overflow-hidden lg:hidden">
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-black/60 backdrop-blur-xs transition-opacity"
        onClick={onClose}
        aria-label="Close mobile menu"
      />

      {/* Drawer */}
      <div className="fixed inset-y-0 left-0 max-w-[85vw] w-80 bg-white shadow-2xl flex flex-col z-10 animate-fade-in">
        {/* Drawer Header */}
        <div className="p-4 bg-[#FFF8EF] border-b border-[#FCBF49]/30 flex items-center justify-between">
          <Logo size="sm" />
          <button
            type="button"
            onClick={onClose}
            className="w-9 h-9 rounded-full bg-white text-gray-500 hover:text-[#D62828] border border-gray-200 flex items-center justify-center"
            aria-label="Close navigation"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Quick Search Button in Mobile Drawer */}
        <div className="p-4 border-b border-gray-100">
          <button
            type="button"
            onClick={() => {
              onClose();
              onOpenSearch();
            }}
            className="w-full py-2.5 px-4 rounded-xl bg-gray-100 text-gray-500 text-xs font-semibold flex items-center gap-2 hover:bg-gray-200 transition-colors text-left"
          >
            <span>🔍</span>
            <span>Search food, biryani, burgers...</span>
          </button>
        </div>

        {/* Nav Links */}
        <nav className="flex-1 overflow-y-auto p-4 space-y-1">
          {navLinks.map((link) => {
            const Icon = link.icon;
            const isActive = location.pathname === link.path;

            return (
              <Link
                key={link.path}
                to={link.path}
                onClick={onClose}
                className={`flex items-center justify-between px-4 py-3 rounded-2xl text-sm font-bold transition-all ${
                  isActive
                    ? 'bg-[#FFECEC] text-[#D62828] shadow-xs'
                    : 'text-gray-700 hover:bg-[#FFF8EF] hover:text-[#D62828]'
                }`}
              >
                <div className="flex items-center gap-3">
                  <Icon className={`w-4 h-4 ${isActive ? 'text-[#D62828]' : 'text-gray-400'}`} />
                  <span>{link.label}</span>
                </div>
                {link.badge && (
                  <span className="px-2 py-0.5 rounded-full bg-[#FCBF49] text-[#1F1F1F] text-[10px] font-black uppercase">
                    {link.badge}
                  </span>
                )}
              </Link>
            );
          })}

          <div className="pt-4 mt-4 border-t border-gray-100">
            <Link
              to="/menu"
              onClick={onClose}
              className="w-full py-3.5 px-4 rounded-2xl bg-gradient-to-r from-[#D62828] to-[#F77F00] text-white text-xs font-black flex items-center justify-center gap-2 shadow-md shadow-[#D62828]/25"
            >
              <ShoppingBag className="w-4 h-4" />
              <span>Order Now Online</span>
            </Link>
          </div>
        </nav>

        {/* Drawer Footer with Quick Contact */}
        <div className="p-4 bg-[#FFF8EF] border-t border-[#FCBF49]/30 space-y-2 text-xs">
          <div className="flex items-center gap-2 text-gray-600">
            <Clock className="w-3.5 h-3.5 text-[#F77F00] shrink-0" />
            <span className="truncate">{RESTAURANT_INFO.openingHours}</span>
          </div>

          <div className="flex items-center gap-2 text-gray-600">
            <MapPin className="w-3.5 h-3.5 text-[#D62828] shrink-0" />
            <span className="truncate">{RESTAURANT_INFO.city}, Pakistan</span>
          </div>

          <a
            href={getWhatsAppUrl()}
            target="_blank"
            rel="noopener noreferrer"
            className="mt-2 flex items-center justify-center gap-2 py-2.5 px-3 rounded-xl bg-[#25D366] text-white font-bold text-xs shadow-xs"
          >
            <MessageCircle className="w-4 h-4" />
            <span>Chat on WhatsApp</span>
          </a>
        </div>
      </div>
    </div>
  );
};
