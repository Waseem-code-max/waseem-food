import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import {
  Menu as MenuIcon,
  Search,
  ShoppingBag,
  ArrowRight,
  Flame,
  X,
} from 'lucide-react';
import { Logo } from './Logo';
import { MobileMenu } from './MobileMenu';
import { SearchBar } from './SearchBar';
import { useCart } from '../context/CartContext';
import { RESTAURANT_INFO } from '../config/restaurant';

export const Header: React.FC = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const { totalItems, openCart } = useCart();
  const location = useLocation();

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { label: 'Home', path: '/' },
    { label: 'Menu', path: '/menu' },
    { label: 'Deals', path: '/deals', badge: 'Hot' },
    { label: 'About', path: '/about' },
    { label: 'Contact', path: '/contact' },
  ];

  return (
    <>
      <header
        className={`sticky top-0 z-40 w-full transition-all duration-300 ${
          isScrolled
            ? 'bg-white/95 backdrop-blur-md shadow-sm border-b border-gray-100 py-2.5'
            : 'bg-[#FFF8EF] border-b border-[#FCBF49]/20 py-3.5'
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between gap-4">
            
            {/* Mobile Left: Hamburger Button */}
            <div className="flex items-center gap-2 lg:hidden">
              <button
                type="button"
                onClick={() => setIsMobileMenuOpen(true)}
                className="w-10 h-10 rounded-xl bg-white border border-gray-200 text-[#1F1F1F] flex items-center justify-center shadow-2xs hover:bg-gray-50 active:scale-95 transition-all"
                aria-label="Open mobile navigation menu"
              >
                <MenuIcon className="w-5 h-5" />
              </button>
            </div>

            {/* Logo */}
            <div className="flex items-center shrink-0">
              <Logo size="md" />
            </div>

            {/* Desktop Navigation Links */}
            <nav className="hidden lg:flex items-center gap-1 xl:gap-2">
              {navLinks.map((link) => {
                const isActive = location.pathname === link.path;
                return (
                  <Link
                    key={link.path}
                    to={link.path}
                    className={`relative px-3.5 py-2 rounded-xl text-sm font-bold transition-colors ${
                      isActive
                        ? 'text-[#D62828] bg-[#FFECEC]'
                        : 'text-[#1F1F1F] hover:text-[#D62828] hover:bg-white/70'
                    }`}
                  >
                    <span>{link.label}</span>
                    {link.badge && (
                      <span className="ml-1.5 px-1.5 py-0.2 text-[10px] font-black rounded-full bg-[#FCBF49] text-[#1F1F1F] uppercase inline-flex items-center gap-0.5">
                        <Flame className="w-2.5 h-2.5 fill-current text-[#D62828]" />
                        {link.badge}
                      </span>
                    )}
                  </Link>
                );
              })}
            </nav>

            {/* Desktop Search Bar (Mid-sized) */}
            <div className="hidden md:block flex-1 max-w-xs xl:max-w-sm mx-2">
              <SearchBar placeholder="Search biryani, zinger..." />
            </div>

            {/* Right Action Area */}
            <div className="flex items-center gap-2 sm:gap-3">
              {/* Mobile Search Button Toggle */}
              <button
                type="button"
                onClick={() => setIsSearchOpen(!isSearchOpen)}
                className="md:hidden w-10 h-10 rounded-xl bg-white border border-gray-200 text-gray-700 flex items-center justify-center hover:text-[#D62828] transition-colors shadow-2xs"
                aria-label="Toggle search"
              >
                {isSearchOpen ? <X className="w-4 h-4" /> : <Search className="w-4 h-4" />}
              </button>

              {/* Cart Button */}
              <button
                type="button"
                id="header-cart-btn"
                onClick={openCart}
                className="relative px-3 sm:px-4 py-2 sm:py-2.5 rounded-xl bg-white border border-[#FCBF49]/40 text-[#1F1F1F] hover:border-[#D62828] shadow-xs flex items-center gap-2 transition-all cursor-pointer group active:scale-95"
                aria-label="Shopping Cart"
              >
                <div className="relative">
                  <ShoppingBag className="w-5 h-5 text-[#D62828] group-hover:scale-110 transition-transform" />
                  {totalItems > 0 && (
                    <span className="absolute -top-2 -right-2.5 bg-[#D62828] text-white text-[11px] font-black w-5 h-5 rounded-full flex items-center justify-center shadow-md animate-scale">
                      {totalItems}
                    </span>
                  )}
                </div>
                <span className="hidden sm:inline text-xs font-extrabold text-[#1F1F1F]">
                  Cart
                </span>
              </button>

              {/* Order Now Button (Desktop) */}
              <Link
                to="/menu"
                id="header-order-now-btn"
                className="hidden sm:inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-[#F77F00] hover:bg-[#E06F00] text-white text-xs font-black uppercase tracking-wider shadow-md shadow-[#F77F00]/25 active:scale-95 transition-all"
              >
                <span>Order Now</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </Link>
            </div>

          </div>

          {/* Mobile Search Dropdown Bar */}
          {isSearchOpen && (
            <div className="md:hidden pt-3 pb-1">
              <SearchBar
                placeholder="Search biryani, zinger, karahi..."
                onSearch={() => {}}
              />
            </div>
          )}
        </div>
      </header>

      {/* Mobile Navigation Drawer */}
      <MobileMenu
        isOpen={isMobileMenuOpen}
        onClose={() => setIsMobileMenuOpen(false)}
        onOpenSearch={() => {
          setIsMobileMenuOpen(false);
          setIsSearchOpen(true);
        }}
      />
    </>
  );
};
