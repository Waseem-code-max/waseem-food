import React from 'react';
import { Leaf, Zap, Award, Wallet, ShieldCheck, HeartHandshake } from 'lucide-react';

export const WhyChooseUs: React.FC = () => {
  const features = [
    {
      icon: Leaf,
      title: "Fresh Ingredients",
      description: "Fresh ingredients and carefully prepared meals every single day. We source poultry and produce from certified local vendors.",
      color: "bg-[#2A9D8F]/10 text-[#2A9D8F]",
      border: "hover:border-[#2A9D8F]/40",
    },
    {
      icon: Zap,
      title: "Fast Delivery",
      description: "Hot food delivered quickly right to your doorstep. Thermal insulated bags maintain piping-hot temperatures.",
      color: "bg-[#F77F00]/10 text-[#F77F00]",
      border: "hover:border-[#F77F00]/40",
    },
    {
      icon: Award,
      title: "Best Taste",
      description: "Traditional flavors with modern presentation. Time-tested secret spice blends honed by seasoned Pakistani chefs.",
      color: "bg-[#D62828]/10 text-[#D62828]",
      border: "hover:border-[#D62828]/40",
    },
    {
      icon: Wallet,
      title: "Affordable Prices",
      description: "Delicious food at prices everyone can enjoy. Premium restaurant dining taste without burning a hole in your pocket.",
      color: "bg-[#FCBF49]/20 text-[#D48B00]",
      border: "hover:border-[#FCBF49]/60",
    },
  ];

  return (
    <section className="py-16 sm:py-20 bg-white border-y border-gray-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Heading */}
        <div className="text-center max-w-2xl mx-auto mb-14">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#FFF8EF] text-[#F77F00] text-xs font-black uppercase tracking-wider mb-3">
            <HeartHandshake className="w-3.5 h-3.5" />
            <span>Our Quality Promise</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-black text-[#1F1F1F] font-display tracking-tight">
            Why Choose Waseem Food?
          </h2>
          <p className="text-gray-600 text-sm sm:text-base mt-3 leading-relaxed">
            From our sizzling karahi stoves to your family dinner table, we adhere to the highest culinary standards of taste, hygiene, and hospitality.
          </p>
        </div>

        {/* 4 Feature Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {features.map((feature, index) => {
            const Icon = feature.icon;
            return (
              <div
                key={index}
                className={`p-6 sm:p-7 rounded-3xl bg-[#FFF8EF]/50 border border-gray-100 shadow-2xs hover:shadow-xl transition-all duration-300 hover:-translate-y-1 ${feature.border} flex flex-col justify-between`}
              >
                <div>
                  <div className={`w-14 h-14 rounded-2xl ${feature.color} flex items-center justify-center mb-5 shadow-xs`}>
                    <Icon className="w-7 h-7" />
                  </div>
                  <h3 className="text-lg font-bold text-[#1F1F1F] mb-2">
                    {feature.title}
                  </h3>
                  <p className="text-xs sm:text-sm text-gray-600 leading-relaxed">
                    {feature.description}
                  </p>
                </div>

                <div className="mt-6 pt-4 border-t border-gray-200/50 flex items-center gap-1.5 text-xs font-bold text-[#1F1F1F]">
                  <ShieldCheck className="w-4 h-4 text-[#D62828]" />
                  <span>Guaranteed Fresh</span>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
