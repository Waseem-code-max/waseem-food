import React from 'react';
import { Product } from '../types';
import { ProductCard } from './ProductCard';
import { Utensils } from 'lucide-react';

interface ProductGridProps {
  products: Product[];
  emptyMessage?: string;
  emptySubtitle?: string;
  columns?: '3' | '4';
}

export const ProductGrid: React.FC<ProductGridProps> = ({
  products,
  emptyMessage = "No delicious items found",
  emptySubtitle = "Try adjusting your filters or search terms.",
  columns = '4',
}) => {
  if (products.length === 0) {
    return (
      <div className="py-16 px-4 text-center bg-white rounded-3xl border border-dashed border-gray-200 my-4">
        <div className="w-16 h-16 rounded-full bg-[#FFF8EF] text-[#F77F00] mx-auto flex items-center justify-center mb-4">
          <Utensils className="w-8 h-8" />
        </div>
        <h3 className="text-lg font-bold text-[#1F1F1F] mb-1">{emptyMessage}</h3>
        <p className="text-sm text-gray-500 max-w-md mx-auto">{emptySubtitle}</p>
      </div>
    );
  }

  const gridCols =
    columns === '3'
      ? 'grid-cols-1 sm:grid-cols-2 lg:grid-cols-3'
      : 'grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4';

  return (
    <div className={`grid ${gridCols} gap-5 sm:gap-6`}>
      {products.map((product) => (
        <ProductCard key={product.id} product={product} />
      ))}
    </div>
  );
};
