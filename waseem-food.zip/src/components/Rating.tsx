import React from 'react';
import { Star } from 'lucide-react';

interface RatingProps {
  rating: number;
  reviewsCount?: number;
  size?: 'sm' | 'md' | 'lg';
  showCount?: boolean;
}

export const Rating: React.FC<RatingProps> = ({
  rating,
  reviewsCount,
  size = 'sm',
  showCount = true,
}) => {
  const starSizes = {
    sm: 'w-3.5 h-3.5',
    md: 'w-4 h-4',
    lg: 'w-5 h-5',
  };

  const textSizes = {
    sm: 'text-xs',
    md: 'text-sm',
    lg: 'text-base font-semibold',
  };

  return (
    <div className="inline-flex items-center gap-1.5" title={`${rating} out of 5 stars`}>
      <div className="flex items-center text-[#F77F00]">
        {[1, 2, 3, 4, 5].map((star) => {
          const filled = rating >= star;
          const half = rating >= star - 0.5 && !filled;
          return (
            <Star
              key={star}
              className={`${starSizes[size]} ${
                filled
                  ? 'fill-[#FCBF49] text-[#F77F00]'
                  : half
                  ? 'fill-[#FCBF49]/50 text-[#F77F00]'
                  : 'text-gray-300'
              }`}
            />
          );
        })}
      </div>
      <span className={`font-bold text-[#1F1F1F] ${textSizes[size]}`}>
        {rating.toFixed(1)}
      </span>
      {showCount && reviewsCount && (
        <span className="text-gray-500 text-xs">({reviewsCount})</span>
      )}
    </div>
  );
};
