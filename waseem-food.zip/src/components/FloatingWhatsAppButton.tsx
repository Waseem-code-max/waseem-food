import React from 'react';
import { MessageCircle } from 'lucide-react';
import { getWhatsAppUrl, RESTAURANT_INFO } from '../config/restaurant';

interface FloatingWhatsAppButtonProps {
  className?: string;
}

export const FloatingWhatsAppButton: React.FC<FloatingWhatsAppButtonProps> = ({ className = '' }) => {
  const whatsappUrl = getWhatsAppUrl(
    `Hello ${RESTAURANT_INFO.name}, I want to place an order! Could you please share today's menu specials?`
  );

  return (
    <aside aria-label="WhatsApp quick ordering">
      <a
        href={whatsappUrl}
        target="_blank"
        rel="noopener noreferrer"
        id="floating-whatsapp-btn"
        className={`fixed bottom-5 right-5 z-40 flex items-center gap-2.5 px-4 py-3 rounded-full bg-[#25D366] text-white shadow-xl hover:shadow-2xl hover:scale-105 active:scale-95 transition-all duration-300 font-extrabold text-xs sm:text-sm border-2 border-white group ${className}`}
        title={`Order on WhatsApp (${RESTAURANT_INFO.whatsappDisplay})`}
      >
        <div className="relative">
          <MessageCircle className="w-5 h-5 fill-white text-[#25D366]" />
          <span className="absolute -top-1 -right-1 w-2.5 h-2.5 bg-red-500 rounded-full border-2 border-white animate-pulse" />
        </div>
        <span className="hidden xs:inline tracking-tight font-bold">Order on WhatsApp</span>
      </a>
    </aside>
  );
};
