import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, CheckCircle, UtensilsCrossed, Heart } from 'lucide-react';
import { RESTAURANT_INFO } from '../config/restaurant';

export const AboutSection: React.FC = () => {
  return (
    <section className="py-16 sm:py-20 bg-[#FFF8EF] overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          
          {/* Images Layout */}
          <div className="lg:col-span-6 relative">
            <div className="relative mx-auto max-w-lg lg:max-w-none">
              
              {/* Main Image */}
              <div className="rounded-3xl overflow-hidden shadow-2xl border-4 border-white bg-gray-100">
                <img
                  src="https://images.unsplash.com/photo-1555396273-367ea4eb4db5?auto=format&fit=crop&w=900&q=80"
                  alt="Waseem Food Restaurant ambiance and kitchen preparation"
                  className="w-full h-[360px] sm:h-[420px] object-cover"
                  loading="lazy"
                />
              </div>

              {/* Overlapping Secondary Food Image */}
              <div className="absolute -bottom-8 -right-4 sm:-right-8 w-44 sm:w-56 h-44 sm:h-56 rounded-3xl overflow-hidden shadow-2xl border-4 border-white hidden xs:block">
                <img
                  src="https://images.unsplash.com/photo-1603894584373-5ac82b2ae398?auto=format&fit=crop&w=600&q=80"
                  alt="Desi Karahi fresh from the wok"
                  className="w-full h-full object-cover"
                  loading="lazy"
                />
              </div>

              {/* Experience Badge */}
              <div className="absolute -top-6 -left-4 sm:-left-6 bg-gradient-to-br from-[#D62828] to-[#F77F00] text-white p-4 sm:p-5 rounded-3xl shadow-xl flex items-center gap-3">
                <span className="text-3xl sm:text-4xl font-black font-display">15+</span>
                <div className="text-xs font-bold leading-tight">
                  <span>Years of</span>
                  <br />
                  <span className="text-[#FCBF49]">Authentic Flavor</span>
                </div>
              </div>

            </div>
          </div>

          {/* Text Content */}
          <div className="lg:col-span-6 flex flex-col items-start">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#FFECEC] text-[#D62828] text-xs font-black uppercase tracking-wider mb-3">
              <UtensilsCrossed className="w-3.5 h-3.5" />
              <span>About Waseem Food</span>
            </div>

            <h2 className="text-3xl sm:text-4xl md:text-5xl font-black text-[#1F1F1F] font-display tracking-tight leading-tight">
              Good Food. <br />
              <span className="text-[#D62828]">Good Mood.</span>
            </h2>

            <p className="mt-4 text-base text-gray-700 leading-relaxed">
              At <strong>{RESTAURANT_INFO.name}</strong>, we believe every meal should be a memorable celebration of authentic Pakistani heritage. Founded with a deep passion for traditional culinary arts, our journey started with a single promise: uncompromised taste, fresh local ingredients, and generous hospitality.
            </p>

            <p className="mt-3 text-sm text-gray-600 leading-relaxed">
              Whether you are enjoying our slow-dum Chicken Biryani, sizzling wok Karahis, fiery BBQ platters, or our crave-worthy crispy Zinger Burgers, each recipe is crafted with premium spices, 100% Halal chicken, and zero shortcuts.
            </p>

            {/* Quality Statement Bullet Points */}
            <div className="mt-6 space-y-3 w-full">
              {[
                "100% certified Halal meat and daily fresh poultry",
                "Pure desi ghee & cold-pressed oils used for traditional dishes",
                "Hygienic open kitchen with strict temperature & safety controls",
                "Lightning fast delivery across the city with insulated food carriers"
              ].map((point, index) => (
                <div key={index} className="flex items-center gap-3">
                  <div className="w-5 h-5 rounded-full bg-[#FCBF49]/30 text-[#D62828] flex items-center justify-center shrink-0">
                    <CheckCircle className="w-3.5 h-3.5 fill-[#D62828] text-white" />
                  </div>
                  <span className="text-xs sm:text-sm font-semibold text-[#1F1F1F]">
                    {point}
                  </span>
                </div>
              ))}
            </div>

            {/* CTA Button */}
            <div className="mt-8">
              <Link
                to="/menu"
                id="about-explore-menu-btn"
                className="px-8 py-4 rounded-2xl bg-[#F77F00] hover:bg-[#E06F00] text-white font-black text-sm sm:text-base shadow-lg shadow-[#F77F00]/25 hover:shadow-xl hover:-translate-y-0.5 active:scale-98 transition-all inline-flex items-center gap-2"
              >
                <span>Explore Our Menu</span>
                <ArrowRight className="w-4 h-4" />
              </Link>
            </div>

          </div>

        </div>
      </div>
    </section>
  );
};
