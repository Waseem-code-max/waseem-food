import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, Flame, Sparkles } from 'lucide-react';
import { DEALS } from '../data/deals';
import { DealCard } from './DealCard';

export const DealsSection: React.FC = () => {
  // Show first 3 top deals on the home page as requested
  const featuredDeals = DEALS.slice(0, 3);

  return (
    <section id="special-deals-section" className="py-16 bg-[#FFF8EF] relative overflow-hidden">
      {/* Decorative subtle background elements */}
      <div className="absolute -top-24 -right-24 w-96 h-96 bg-[#FCBF49]/15 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute -bottom-24 -left-24 w-96 h-96 bg-[#D62828]/10 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-10 gap-4">
          <div>
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#FFECEC] text-[#D62828] text-xs font-black uppercase tracking-wider mb-3">
              <Flame className="w-3.5 h-3.5 fill-current" />
              <span>Limited Time Offers</span>
            </div>
            <h2 className="text-3xl sm:text-4xl font-black text-[#1F1F1F] font-display tracking-tight">
              Special Deals
            </h2>
            <p className="text-gray-600 text-sm sm:text-base mt-2 max-w-xl">
              Save more with our curated family packs, combo platters, and midnight cravings boxes. Made fresh upon every order!
            </p>
          </div>

          <Link
            to="/deals"
            className="inline-flex items-center gap-2 text-sm font-bold text-[#D62828] hover:text-[#B71C1C] transition-colors group self-start md:self-auto"
          >
            <span>View All Deals ({DEALS.length})</span>
            <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
          </Link>
        </div>

        {/* Deals List */}
        <div className="space-y-6">
          {featuredDeals.map((deal) => (
            <DealCard key={deal.id} deal={deal} />
          ))}
        </div>

        {/* Bottom Banner */}
        <div className="mt-10 p-6 sm:p-8 rounded-3xl bg-gradient-to-r from-[#D62828] via-[#E63946] to-[#F77F00] text-white flex flex-col sm:flex-row items-center justify-between gap-6 shadow-xl">
          <div className="flex items-center gap-4 text-center sm:text-left">
            <div className="w-14 h-14 rounded-2xl bg-white/15 backdrop-blur-md flex items-center justify-center shrink-0">
              <Sparkles className="w-7 h-7 text-[#FCBF49]" />
            </div>
            <div>
              <h4 className="text-xl font-extrabold text-white">
                Planning a Party or Corporate Event?
              </h4>
              <p className="text-xs sm:text-sm text-white/90 mt-1">
                We cater customized Pakistani BBQ platters and authentic Biryani degs at wholesale rates.
              </p>
            </div>
          </div>

          <Link
            to="/contact"
            className="px-6 py-3 rounded-2xl bg-white text-[#D62828] font-black text-sm hover:bg-[#FFF8EF] transition-all shadow-lg active:scale-95 shrink-0"
          >
            Inquire Bulk Order
          </Link>
        </div>
      </div>
    </section>
  );
};
