import React from 'react';
import { Link } from 'react-router-dom';
import { Utensils, Flame } from 'lucide-react';

interface LogoProps {
  className?: string;
  size?: 'sm' | 'md' | 'lg';
  imageSrc?: string; // Optional: To easily replace with an actual image logo later
}

export const Logo: React.FC<LogoProps> = ({
  className = '',
  size = 'md',
  imageSrc,
}) => {
  // If an actual image logo is provided later, render it directly
  if (imageSrc) {
    return (
      <Link to="/" className={`inline-flex items-center gap-2 ${className}`}>
        <img src={imageSrc} alt="Waseem Food Logo" className="h-10 w-auto object-contain" />
      </Link>
    );
  }

  const sizes = {
    sm: {
      box: 'w-8 h-8 rounded-xl',
      icon: 'w-4 h-4',
      waseem: 'text-base leading-tight tracking-wider',
      food: 'text-[10px] tracking-[0.25em]',
    },
    md: {
      box: 'w-10 h-10 rounded-2xl',
      icon: 'w-5 h-5',
      waseem: 'text-xl leading-none tracking-wider',
      food: 'text-xs tracking-[0.28em]',
    },
    lg: {
      box: 'w-14 h-14 rounded-3xl',
      icon: 'w-7 h-7',
      waseem: 'text-3xl leading-none tracking-wider',
      food: 'text-sm tracking-[0.3em]',
    },
  };

  const current = sizes[size];

  return (
    <Link
      to="/"
      id="brand-logo"
      className={`group inline-flex items-center gap-2.5 select-none focus:outline-none focus-visible:ring-2 focus-visible:ring-[#D62828] rounded-xl p-1 transition-transform active:scale-98 ${className}`}
      title="Waseem Food - Home"
    >
      {/* Visual Treatment Badge */}
      <div className={`${current.box} bg-gradient-to-br from-[#D62828] via-[#E63946] to-[#F77F00] shadow-md shadow-[#D62828]/25 flex items-center justify-center text-white relative overflow-hidden transition-transform group-hover:scale-105 duration-200`}>
        <div className="absolute inset-0 bg-radial from-white/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
        <div className="relative flex items-center justify-center">
          <Utensils className={`${current.icon} text-white drop-shadow-xs`} />
          <Flame className="w-2.5 h-2.5 text-[#FCBF49] absolute -top-1 -right-1 animate-pulse" />
        </div>
      </div>

      {/* Prominent Text Logo */}
      <div className="flex flex-col justify-center">
        <div className="flex items-center gap-1">
          <span className={`font-extrabold ${current.waseem} text-[#1F1F1F] font-sans tracking-tight`}>
            WASEEM
          </span>
          <span className="w-1.5 h-1.5 rounded-full bg-[#D62828] inline-block mb-1" />
        </div>
        <div className="flex items-center justify-between">
          <span className={`font-black ${current.food} text-[#D62828] uppercase`}>
            FOOD
          </span>
          <span className="text-[9px] font-bold text-[#F77F00] uppercase bg-[#FFF8EF] px-1 py-0.2 rounded">
            PK
          </span>
        </div>
      </div>
    </Link>
  );
};
