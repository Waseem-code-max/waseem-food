import React from 'react';
import { Check, Flame, ShoppingBag, Users, Sparkles } from 'lucide-react';
import { Deal } from '../types';
import { useCart } from '../context/CartContext';
import { RESTAURANT_INFO } from '../config/restaurant';

interface DealCardProps {
  deal: Deal;
  className?: string;
}

export const DealCard: React.FC<DealCardProps> = ({ deal, className = '' }) => {
  const { addToCart, items } = useCart();
  const cartItem = items.find((i) => i.itemId === deal.id && i.itemType === 'deal');
  const inCart = !!cartItem;

  const handleOrderDeal = (e: React.MouseEvent) => {
    e.preventDefault();
    addToCart(deal, 1);
  };

  return (
    <div
      id={`deal-card-${deal.id}`}
      className={`group relative flex flex-col md:flex-row bg-white rounded-3xl border-2 border-[#FCBF49]/60 shadow-md hover:shadow-2xl hover:border-[#F77F00] transition-all duration-300 overflow-hidden ${className}`}
    >
      {/* Visual Image Section */}
      <div className="relative md:w-5/12 min-h-[220px] md:min-h-[260px] overflow-hidden bg-gray-900">
        <img
          src={deal.image}
          alt={deal.name}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500 opacity-90 group-hover:opacity-100"
          loading="lazy"
        />
        <div className="absolute inset-0 bg-gradient-to-t md:bg-gradient-to-r from-black/80 via-black/30 to-transparent" />

        {/* Promo Badge */}
        {deal.badge && (
          <div className="absolute top-4 left-4 bg-gradient-to-r from-[#D62828] to-[#F77F00] text-white text-xs font-black px-3 py-1.5 rounded-full shadow-lg flex items-center gap-1.5 uppercase tracking-wider">
            <Flame className="w-3.5 h-3.5 fill-[#FCBF49] text-[#FCBF49]" />
            <span>{deal.badge}</span>
          </div>
        )}

        {/* Discount Tag */}
        <div className="absolute bottom-4 left-4 bg-[#FCBF49] text-[#1F1F1F] font-black text-xs px-3 py-1 rounded-lg shadow-md border border-white/50">
          Save {deal.discount}%
        </div>

        {/* Serves Tag */}
        {deal.serves && (
          <div className="absolute top-4 right-4 bg-black/60 backdrop-blur-xs text-white text-xs font-semibold px-2.5 py-1 rounded-full flex items-center gap-1">
            <Users className="w-3 h-3 text-[#FCBF49]" />
            <span>{deal.serves}</span>
          </div>
        )}
      </div>

      {/* Details & Contents Section */}
      <div className="p-6 md:w-7/12 flex flex-col justify-between bg-gradient-to-br from-white to-[#FFF8EF]/50">
        <div>
          <div className="flex items-start justify-between gap-2">
            <div>
              <span className="text-[11px] font-extrabold uppercase tracking-widest text-[#F77F00] flex items-center gap-1">
                <Sparkles className="w-3 h-3 text-[#FCBF49]" /> Exclusive Deal
              </span>
              <h3 className="text-xl sm:text-2xl font-black text-[#1F1F1F] mt-0.5 group-hover:text-[#D62828] transition-colors">
                {deal.name}
              </h3>
            </div>
          </div>

          <p className="text-xs sm:text-sm text-gray-600 mt-1.5 line-clamp-2">
            {deal.description}
          </p>

          {/* Included Items List */}
          <div className="mt-4 p-3 rounded-2xl bg-white border border-[#FCBF49]/30 shadow-2xs">
            <p className="text-[11px] font-bold text-gray-500 uppercase tracking-wider mb-2">
              What&apos;s Included in this Deal:
            </p>
            <ul className="space-y-1.5">
              {deal.includedItems.map((item, idx) => (
                <li key={idx} className="flex items-center gap-2 text-xs font-semibold text-[#1F1F1F]">
                  <div className="w-4 h-4 rounded-full bg-[#FFECEC] text-[#D62828] flex items-center justify-center shrink-0">
                    <Check className="w-2.5 h-2.5 stroke-[3]" />
                  </div>
                  <span>{item}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Pricing & Order CTA */}
        <div className="mt-5 pt-4 border-t border-gray-100 flex items-center justify-between gap-3">
          <div>
            <span className="text-[10px] uppercase font-bold text-gray-400 block">Deal Price</span>
            <div className="flex items-baseline gap-2">
              <span className="text-2xl font-black text-[#D62828]">
                {RESTAURANT_INFO.currency} {deal.price.toLocaleString()}
              </span>
              <span className="text-xs text-gray-400 line-through font-medium">
                {RESTAURANT_INFO.currency} {deal.oldPrice.toLocaleString()}
              </span>
            </div>
          </div>

          <button
            type="button"
            id={`order-deal-${deal.id}`}
            onClick={handleOrderDeal}
            className={`px-5 py-3 rounded-2xl font-black text-sm flex items-center gap-2 transition-all shadow-md active:scale-95 cursor-pointer ${
              inCart
                ? 'bg-[#1F1F1F] text-[#FCBF49] hover:bg-[#D62828] hover:text-white'
                : 'bg-gradient-to-r from-[#F77F00] to-[#E06F00] text-white hover:from-[#E06F00] hover:to-[#D62828] shadow-[#F77F00]/30'
            }`}
          >
            {inCart ? (
              <>
                <Check className="w-4 h-4 text-[#FCBF49]" />
                <span>Deal Added ({cartItem?.quantity})</span>
              </>
            ) : (
              <>
                <ShoppingBag className="w-4 h-4" />
                <span>Order Deal</span>
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
