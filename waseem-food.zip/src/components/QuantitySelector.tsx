import React from 'react';
import { Minus, Plus } from 'lucide-react';

interface QuantitySelectorProps {
  quantity: number;
  onIncrease: () => void;
  onDecrease: () => void;
  size?: 'sm' | 'md' | 'lg';
  min?: number;
  max?: number;
}

export const QuantitySelector: React.FC<QuantitySelectorProps> = ({
  quantity,
  onIncrease,
  onDecrease,
  size = 'md',
  min = 1,
  max = 99,
}) => {
  const sizeClasses = {
    sm: {
      btn: 'w-7 h-7 text-xs',
      text: 'w-7 text-xs font-semibold',
      icon: 'w-3 h-3',
    },
    md: {
      btn: 'w-8 h-8 text-sm',
      text: 'w-9 text-sm font-bold',
      icon: 'w-3.5 h-3.5',
    },
    lg: {
      btn: 'w-10 h-10 text-base',
      text: 'w-12 text-base font-bold',
      icon: 'w-4 h-4',
    },
  };

  const currentSize = sizeClasses[size];

  return (
    <div className="inline-flex items-center rounded-xl bg-white border border-[#FCBF49]/40 shadow-xs p-0.5">
      <button
        type="button"
        onClick={(e) => {
          e.stopPropagation();
          onDecrease();
        }}
        disabled={quantity <= min}
        aria-label="Decrease quantity"
        className={`${currentSize.btn} flex items-center justify-center rounded-lg text-[#1F1F1F] hover:bg-[#FFF8EF] hover:text-[#D62828] disabled:opacity-40 disabled:hover:bg-transparent transition-colors`}
      >
        <Minus className={currentSize.icon} />
      </button>

      <span className={`${currentSize.text} text-center select-none text-[#1F1F1F]`}>
        {quantity}
      </span>

      <button
        type="button"
        onClick={(e) => {
          e.stopPropagation();
          onIncrease();
        }}
        disabled={quantity >= max}
        aria-label="Increase quantity"
        className={`${currentSize.btn} flex items-center justify-center rounded-lg text-[#1F1F1F] hover:bg-[#FFF8EF] hover:text-[#D62828] disabled:opacity-40 disabled:hover:bg-transparent transition-colors`}
      >
        <Plus className={currentSize.icon} />
      </button>
    </div>
  );
};
