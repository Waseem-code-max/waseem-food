import React from 'react';
import { useNavigate } from 'react-router-dom';
import { X, Trash2, ShoppingBag, ArrowRight, ShieldCheck, Tag } from 'lucide-react';
import { useCart } from '../context/CartContext';
import { QuantitySelector } from './QuantitySelector';
import { RESTAURANT_INFO } from '../config/restaurant';

export const CartDrawer: React.FC = () => {
  const {
    items,
    isCartOpen,
    closeCart,
    updateQuantity,
    removeFromCart,
    subtotal,
    deliveryFee,
    total,
    totalItems,
    clearCart,
  } = useCart();

  const navigate = useNavigate();

  if (!isCartOpen) return null;

  const handleCheckout = () => {
    closeCart();
    navigate('/checkout');
  };

  const freeDeliveryRemaining = RESTAURANT_INFO.freeDeliveryThreshold - subtotal;

  return (
    <div className="fixed inset-0 z-50 overflow-hidden">
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-black/60 backdrop-blur-xs transition-opacity animate-fade-in"
        onClick={closeCart}
        aria-label="Close cart drawer"
      />

      <div className="fixed inset-y-0 right-0 max-w-full flex pl-10">
        <div className="w-screen max-w-md bg-white shadow-2xl flex flex-col">
          
          {/* Drawer Header */}
          <div className="p-5 bg-[#FFF8EF] border-b border-[#FCBF49]/30 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-2xl bg-[#D62828] text-white flex items-center justify-center shadow-sm">
                <ShoppingBag className="w-5 h-5" />
              </div>
              <div>
                <h2 className="text-lg font-black text-[#1F1F1F]">Your Order</h2>
                <p className="text-xs text-gray-500 font-medium">
                  {totalItems} item{totalItems !== 1 ? 's' : ''} in your cart
                </p>
              </div>
            </div>

            <div className="flex items-center gap-1">
              {items.length > 0 && (
                <button
                  type="button"
                  onClick={clearCart}
                  className="text-xs text-gray-400 hover:text-[#D62828] px-2 py-1 rounded transition-colors"
                  title="Clear all items"
                >
                  Clear
                </button>
              )}
              <button
                type="button"
                onClick={closeCart}
                className="w-9 h-9 rounded-full bg-white border border-gray-200 text-gray-500 hover:text-[#D62828] hover:border-[#D62828] flex items-center justify-center transition-colors"
                aria-label="Close drawer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* Free Delivery Bar */}
          {subtotal > 0 && (
            <div className="px-5 py-2.5 bg-[#FFF4E5] border-b border-[#FCBF49]/20 flex items-center gap-2 text-xs">
              <Tag className="w-3.5 h-3.5 text-[#F77F00] shrink-0" />
              {freeDeliveryRemaining > 0 ? (
                <span className="text-gray-700">
                  Add <strong className="text-[#D62828]">{RESTAURANT_INFO.currency} {freeDeliveryRemaining.toLocaleString()}</strong> more for <strong>FREE Delivery!</strong>
                </span>
              ) : (
                <span className="text-[#2A9D8F] font-bold">
                  🎉 You unlocked FREE Delivery!
                </span>
              )}
            </div>
          )}

          {/* Cart Items List */}
          <div className="flex-1 overflow-y-auto p-5 space-y-4">
            {items.length === 0 ? (
              <div className="h-full flex flex-col items-center justify-center text-center py-12">
                <div className="w-20 h-20 rounded-full bg-[#FFF8EF] text-[#D62828] flex items-center justify-center mb-4 border border-[#FCBF49]/30">
                  <ShoppingBag className="w-10 h-10 stroke-[1.5]" />
                </div>
                <h3 className="text-lg font-black text-[#1F1F1F]">Your Cart is Empty</h3>
                <p className="text-xs sm:text-sm text-gray-500 max-w-xs mt-1 leading-relaxed">
                  Looks like you haven&apos;t added any delicious food yet. Check out our biryanis, burgers and special deals!
                </p>
                <button
                  type="button"
                  onClick={() => {
                    closeCart();
                    navigate('/menu');
                  }}
                  className="mt-6 px-6 py-3 rounded-2xl bg-[#F77F00] hover:bg-[#E06F00] text-white font-bold text-xs shadow-md transition-all active:scale-95"
                >
                  Browse Delicious Menu
                </button>
              </div>
            ) : (
              items.map((item) => (
                <div
                  key={item.id}
                  className="flex gap-3 p-3.5 rounded-2xl bg-[#FFF8EF]/40 border border-gray-100 hover:border-[#FCBF49]/40 transition-colors"
                >
                  {/* Thumbnail */}
                  <img
                    src={item.image}
                    alt={item.name}
                    className="w-18 h-18 rounded-xl object-cover shrink-0 border border-white shadow-2xs"
                  />

                  {/* Details */}
                  <div className="flex-1 min-w-0 flex flex-col justify-between">
                    <div>
                      <div className="flex items-start justify-between gap-1">
                        <h4 className="text-xs sm:text-sm font-bold text-[#1F1F1F] truncate">
                          {item.name}
                        </h4>
                        <button
                          type="button"
                          onClick={() => removeFromCart(item.id)}
                          aria-label={`Remove ${item.name}`}
                          className="text-gray-400 hover:text-[#D62828] p-1 transition-colors"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>

                      {item.specialInstructions && (
                        <p className="text-[11px] text-gray-500 italic truncate mt-0.5">
                          Note: {item.specialInstructions}
                        </p>
                      )}

                      <div className="text-xs font-medium text-gray-500 mt-1">
                        {RESTAURANT_INFO.currency} {item.price.toLocaleString()} each
                      </div>
                    </div>

                    {/* Quantity & Item Subtotal */}
                    <div className="mt-2 flex items-center justify-between">
                      <QuantitySelector
                        quantity={item.quantity}
                        onIncrease={() => updateQuantity(item.id, item.quantity + 1)}
                        onDecrease={() => updateQuantity(item.id, item.quantity - 1)}
                        size="sm"
                      />

                      <span className="text-xs sm:text-sm font-extrabold text-[#D62828]">
                        {RESTAURANT_INFO.currency} {(item.price * item.quantity).toLocaleString()}
                      </span>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>

          {/* Drawer Footer / Billing summary */}
          {items.length > 0 && (
            <div className="p-5 bg-white border-t border-gray-100 shadow-lg">
              <div className="space-y-2 text-xs text-gray-600 mb-4">
                <div className="flex justify-between">
                  <span>Subtotal</span>
                  <span className="font-bold text-[#1F1F1F]">
                    {RESTAURANT_INFO.currency} {subtotal.toLocaleString()}
                  </span>
                </div>

                <div className="flex justify-between items-center">
                  <span className="flex items-center gap-1">
                    Delivery Fee
                    {deliveryFee === 0 && (
                      <span className="text-[10px] bg-[#2A9D8F]/15 text-[#2A9D8F] font-bold px-1.5 py-0.2 rounded">
                        FREE
                      </span>
                    )}
                  </span>
                  <span className="font-bold text-[#1F1F1F]">
                    {deliveryFee === 0
                      ? 'FREE'
                      : `${RESTAURANT_INFO.currency} ${deliveryFee.toLocaleString()}`}
                  </span>
                </div>

                <div className="pt-2 border-t border-gray-100 flex justify-between items-baseline text-sm">
                  <span className="font-extrabold text-[#1F1F1F]">Total</span>
                  <span className="text-xl font-black text-[#D62828]">
                    {RESTAURANT_INFO.currency} {total.toLocaleString()}
                  </span>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="space-y-2">
                <button
                  type="button"
                  id="cart-proceed-checkout-btn"
                  onClick={handleCheckout}
                  className="w-full py-3.5 px-4 rounded-2xl bg-gradient-to-r from-[#F77F00] to-[#E06F00] hover:from-[#E06F00] hover:to-[#D62828] text-white font-extrabold text-sm shadow-lg shadow-[#F77F00]/25 transition-all flex items-center justify-center gap-2 active:scale-98 cursor-pointer"
                >
                  <span>Proceed to Checkout</span>
                  <ArrowRight className="w-4 h-4" />
                </button>

                <button
                  type="button"
                  onClick={closeCart}
                  className="w-full py-2.5 px-4 rounded-xl text-xs font-bold text-gray-600 hover:text-[#1F1F1F] hover:bg-gray-100 transition-colors"
                >
                  Continue Shopping
                </button>
              </div>

              <div className="mt-3 flex items-center justify-center gap-2 text-[11px] text-gray-400">
                <ShieldCheck className="w-3.5 h-3.5 text-[#2A9D8F]" />
                <span>Safe &amp; contactless delivery available</span>
              </div>
            </div>
          )}

        </div>
      </div>
    </div>
  );
};
