import React, { useRef } from 'react';
import {
  UtensilsCrossed,
  Flame,
  Sandwich,
  Pizza,
  Drumstick,
  FlameKindling,
  Wheat,
  Layers,
  Sparkles,
  CupSoda,
  Cake,
  Tag,
  ChevronLeft,
  ChevronRight,
  LucideIcon,
} from 'lucide-react';
import { CATEGORIES } from '../data/categories';

const ICON_MAP: Record<string, LucideIcon> = {
  UtensilsCrossed,
  Flame,
  Sandwich,
  Pizza,
  Drumstick,
  FlameKindling,
  Wheat,
  Layers,
  Sparkles,
  CupSoda,
  Cake,
  Tag,
};

interface CategoryListProps {
  activeCategory: string;
  onSelectCategory: (categoryName: string) => void;
  className?: string;
  itemCounts?: Record<string, number>;
}

export const CategoryList: React.FC<CategoryListProps> = ({
  activeCategory,
  onSelectCategory,
  className = '',
  itemCounts,
}) => {
  const scrollContainerRef = useRef<HTMLDivElement>(null);

  const handleScroll = (direction: 'left' | 'right') => {
    if (scrollContainerRef.current) {
      const scrollAmount = direction === 'left' ? -240 : 240;
      scrollContainerRef.current.scrollBy({ left: scrollAmount, behavior: 'smooth' });
    }
  };

  return (
    <div className={`relative ${className}`}>
      {/* Scroll arrows for desktop */}
      <button
        type="button"
        onClick={() => handleScroll('left')}
        aria-label="Scroll left"
        className="hidden md:flex absolute -left-4 top-1/2 -translate-y-1/2 z-10 w-9 h-9 rounded-full bg-white text-[#1F1F1F] shadow-lg border border-gray-100 items-center justify-center hover:bg-[#FFF8EF] hover:text-[#D62828] transition-all"
      >
        <ChevronLeft className="w-5 h-5" />
      </button>

      <button
        type="button"
        onClick={() => handleScroll('right')}
        aria-label="Scroll right"
        className="hidden md:flex absolute -right-4 top-1/2 -translate-y-1/2 z-10 w-9 h-9 rounded-full bg-white text-[#1F1F1F] shadow-lg border border-gray-100 items-center justify-center hover:bg-[#FFF8EF] hover:text-[#D62828] transition-all"
      >
        <ChevronRight className="w-5 h-5" />
      </button>

      {/* Horizontally scrollable container */}
      <div
        ref={scrollContainerRef}
        className="flex items-center gap-2.5 sm:gap-3 overflow-x-auto py-2 px-1 no-scrollbar scroll-smooth"
      >
        {CATEGORIES.map((cat) => {
          const Icon = ICON_MAP[cat.iconName] || UtensilsCrossed;
          const isActive = activeCategory.toLowerCase() === cat.name.toLowerCase();
          const count = itemCounts ? itemCounts[cat.name] : undefined;

          return (
            <button
              key={cat.id}
              type="button"
              id={`category-btn-${cat.id}`}
              onClick={() => onSelectCategory(cat.name)}
              className={`group shrink-0 flex items-center gap-2.5 px-4 py-2.5 sm:py-3 rounded-2xl text-xs sm:text-sm font-bold transition-all duration-200 cursor-pointer select-none active:scale-95 ${
                isActive
                  ? 'bg-gradient-to-r from-[#D62828] to-[#F77F00] text-white shadow-md shadow-[#D62828]/25 scale-102'
                  : 'bg-white text-gray-700 hover:bg-[#FFF8EF] hover:text-[#D62828] border border-gray-100 shadow-2xs'
              }`}
            >
              <div
                className={`w-7 h-7 sm:w-8 sm:h-8 rounded-xl flex items-center justify-center transition-colors ${
                  isActive
                    ? 'bg-white/20 text-[#FCBF49]'
                    : 'bg-[#FFF8EF] text-[#F77F00] group-hover:bg-[#FFECEC] group-hover:text-[#D62828]'
                }`}
              >
                <Icon className="w-4 h-4" />
              </div>

              <span>{cat.name}</span>

              {typeof count === 'number' && (
                <span
                  className={`text-[10px] px-1.5 py-0.5 rounded-full font-extrabold ${
                    isActive
                      ? 'bg-white/20 text-white'
                      : 'bg-gray-100 text-gray-500 group-hover:bg-[#FFECEC] group-hover:text-[#D62828]'
                  }`}
                >
                  {count}
                </span>
              )}
            </button>
          );
        })}
      </div>
    </div>
  );
};
