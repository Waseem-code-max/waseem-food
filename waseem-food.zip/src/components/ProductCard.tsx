import React from 'react';
import { Link } from 'react-router-dom';
import { Heart, Plus, ShoppingBag, Check } from 'lucide-react';
import { Product } from '../types';
import { useCart } from '../context/CartContext';
import { Rating } from './Rating';
import { RESTAURANT_INFO } from '../config/restaurant';

interface ProductCardProps {
  product: Product;
  className?: string;
}

export const ProductCard: React.FC<ProductCardProps> = ({ product, className = '' }) => {
  const { addToCart, isFavorite, toggleFavorite, items } = useCart();
  const favorited = isFavorite(product.id);

  // Check if this item is currently in the cart
  const cartItem = items.find((i) => i.itemId === product.id && i.itemType === 'product');
  const inCart = !!cartItem;

  const handleAddToCart = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    addToCart(product, 1);
  };

  const handleToggleFavorite = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    toggleFavorite(product.id);
  };

  return (
    <div
      id={`product-card-${product.id}`}
      className={`group relative flex flex-col bg-white rounded-2xl border border-gray-100 shadow-xs hover:shadow-xl hover:-translate-y-1 transition-all duration-300 overflow-hidden ${className}`}
    >
      {/* Product Image Container */}
      <Link
        to={`/product/${product.slug}`}
        className="relative block aspect-4/3 w-full overflow-hidden bg-gray-100"
      >
        <img
          src={product.image}
          alt={product.name}
          loading="lazy"
          className="w-full h-full object-cover object-center group-hover:scale-106 transition-transform duration-500"
        />

        {/* Gradient overlay for text contrast if needed */}
        <div className="absolute inset-0 bg-gradient-to-t from-black/20 via-transparent to-black/10 pointer-events-none" />

        {/* Discount Badge */}
        {product.discount && product.discount > 0 ? (
          <div className="absolute top-3 left-3 bg-[#FCBF49] text-[#1F1F1F] text-xs font-black px-2.5 py-1 rounded-full shadow-md flex items-center gap-1 uppercase tracking-wide border border-white/40">
            <span>{product.discount}% OFF</span>
          </div>
        ) : product.featured ? (
          <div className="absolute top-3 left-3 bg-[#D62828] text-white text-xs font-bold px-2.5 py-1 rounded-full shadow-md">
            Chef Special
          </div>
        ) : null}

        {/* Favorite/Heart Button */}
        <button
          type="button"
          onClick={handleToggleFavorite}
          aria-label={favorited ? 'Remove from favorites' : 'Add to favorites'}
          className={`absolute top-3 right-3 w-9 h-9 rounded-full flex items-center justify-center shadow-md backdrop-blur-md transition-all active:scale-90 ${
            favorited
              ? 'bg-[#D62828] text-white'
              : 'bg-white/85 text-gray-700 hover:bg-white hover:text-[#D62828]'
          }`}
        >
          <Heart className={`w-4 h-4 ${favorited ? 'fill-current' : ''}`} />
        </button>

        {/* Category tag */}
        <div className="absolute bottom-2 left-3 text-[11px] font-semibold text-white/95 drop-shadow-md bg-black/40 px-2 py-0.5 rounded-md backdrop-blur-xs">
          {product.category}
        </div>
      </Link>

      {/* Content */}
      <div className="p-4 flex-1 flex flex-col justify-between">
        <div>
          {/* Rating */}
          <div className="mb-1.5 flex items-center justify-between">
            <Rating rating={product.rating} reviewsCount={product.reviewsCount} size="sm" />
            {product.prepTime && (
              <span className="text-[11px] text-gray-600 font-medium">
                ⏱ {product.prepTime}
              </span>
            )}
          </div>

          {/* Title */}
          <Link to={`/product/${product.slug}`} className="block">
            <h3 className="font-bold text-base text-[#1F1F1F] group-hover:text-[#D62828] transition-colors line-clamp-1">
              {product.name}
            </h3>
          </Link>

          {/* Description */}
          <p className="text-xs text-gray-500 mt-1 line-clamp-2 leading-relaxed">
            {product.description}
          </p>
        </div>

        {/* Price & Action Row */}
        <div className="mt-4 pt-3 border-t border-gray-100 flex items-center justify-between gap-2">
          <div className="flex flex-col">
            <div className="flex items-baseline gap-1.5">
              <span className="text-base font-extrabold text-[#D62828]">
                {RESTAURANT_INFO.currency} {product.price.toLocaleString()}
              </span>
              {product.oldPrice && (
                <span className="text-xs text-gray-400 line-through font-medium">
                  {RESTAURANT_INFO.currency} {product.oldPrice.toLocaleString()}
                </span>
              )}
            </div>
            <span className="text-[10px] text-gray-600">Freshly prepared</span>
          </div>

          {/* Add to Cart CTA */}
          <button
            type="button"
            id={`add-to-cart-${product.id}`}
            onClick={handleAddToCart}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all shadow-xs active:scale-95 cursor-pointer ${
              inCart
                ? 'bg-[#1F1F1F] text-[#FCBF49] hover:bg-[#D62828] hover:text-white'
                : 'bg-[#F77F00] text-white hover:bg-[#E06F00] shadow-[#F77F00]/25 hover:shadow-md'
            }`}
          >
            {inCart ? (
              <>
                <Check className="w-3.5 h-3.5 text-[#FCBF49]" />
                <span>Added ({cartItem?.quantity})</span>
              </>
            ) : (
              <>
                <Plus className="w-3.5 h-3.5" />
                <span>Add to Cart</span>
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
