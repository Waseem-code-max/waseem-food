import React from 'react';
import { Link } from 'react-router-dom';
import {
  Phone,
  Mail,
  MapPin,
  Clock,
  Heart,
  MessageCircle,
} from 'lucide-react';
import { Logo } from './Logo';
import { RESTAURANT_INFO, getWhatsAppUrl } from '../config/restaurant';

export const Footer: React.FC = () => {
  return (
    <footer className="bg-[#1F1F1F] text-gray-300 pt-16 pb-12 border-t-4 border-[#D62828]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Main 4-Column Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-10 lg:gap-8 pb-12 border-b border-gray-800">
          
          {/* Column 1: Brand Info (4 cols) */}
          <div className="lg:col-span-4 flex flex-col">
            <div className="bg-white/5 p-3 rounded-2xl inline-block w-fit mb-4">
              <Logo size="md" />
            </div>
            <p className="text-gray-400 text-sm leading-relaxed max-w-sm">
              Fresh food, great taste and fast service. Bringing Pakistan&apos;s most cherished traditional recipes and modern fast-food favorites straight to your dining table.
            </p>

            <div className="mt-6 flex items-center gap-2 text-xs font-semibold text-[#FCBF49]">
              <Clock className="w-4 h-4" />
              <span>{RESTAURANT_INFO.openingHours}</span>
            </div>

            <div className="mt-4">
              <a
                href={getWhatsAppUrl()}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-[#25D366] text-white text-xs font-bold hover:bg-[#20bd5a] transition-colors"
              >
                <MessageCircle className="w-4 h-4" />
                <span>WhatsApp: {RESTAURANT_INFO.whatsappDisplay}</span>
              </a>
            </div>
          </div>

          {/* Column 2: Quick Links (2.5 cols) */}
          <div className="lg:col-span-2">
            <h3 className="text-white font-extrabold text-sm uppercase tracking-wider mb-5 flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-[#D62828]" />
              Quick Links
            </h3>
            <ul className="space-y-2.5 text-sm">
              <li>
                <Link to="/" className="text-gray-400 hover:text-[#FCBF49] transition-colors">
                  Home
                </Link>
              </li>
              <li>
                <Link to="/menu" className="text-gray-400 hover:text-[#FCBF49] transition-colors">
                  Full Menu
                </Link>
              </li>
              <li>
                <Link to="/deals" className="text-gray-400 hover:text-[#FCBF49] transition-colors">
                  Special Deals
                </Link>
              </li>
              <li>
                <Link to="/about" className="text-gray-400 hover:text-[#FCBF49] transition-colors">
                  About Us
                </Link>
              </li>
              <li>
                <Link to="/contact" className="text-gray-400 hover:text-[#FCBF49] transition-colors">
                  Contact &amp; Location
                </Link>
              </li>
              <li>
                <Link to="/checkout" className="text-gray-400 hover:text-[#FCBF49] transition-colors">
                  Checkout Cart
                </Link>
              </li>
            </ul>
          </div>

          {/* Column 3: Contact Details (3.5 cols) */}
          <div className="lg:col-span-3">
            <h3 className="text-white font-extrabold text-sm uppercase tracking-wider mb-5 flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-[#F77F00]" />
              Contact Us
            </h3>
            <ul className="space-y-3.5 text-xs sm:text-sm text-gray-400">
              <li className="flex items-start gap-3">
                <MapPin className="w-4 h-4 text-[#D62828] shrink-0 mt-0.5" />
                <span className="leading-snug">{RESTAURANT_INFO.address}</span>
              </li>
              <li className="flex items-center gap-3">
                <Phone className="w-4 h-4 text-[#F77F00] shrink-0" />
                <a href={`tel:${RESTAURANT_INFO.phone}`} className="hover:text-white transition-colors">
                  {RESTAURANT_INFO.displayPhone}
                </a>
              </li>
              <li className="flex items-center gap-3">
                <MessageCircle className="w-4 h-4 text-[#25D366] shrink-0" />
                <a href={getWhatsAppUrl()} target="_blank" rel="noopener noreferrer" className="hover:text-white transition-colors">
                  {RESTAURANT_INFO.whatsappDisplay}
                </a>
              </li>
              <li className="flex items-center gap-3">
                <Mail className="w-4 h-4 text-[#FCBF49] shrink-0" />
                <a href={`mailto:${RESTAURANT_INFO.email}`} className="hover:text-white transition-colors">
                  {RESTAURANT_INFO.email}
                </a>
              </li>
            </ul>
          </div>

          {/* Column 4: Follow Us & Halal Badge (2.5 cols) */}
          <div className="lg:col-span-3">
            <h3 className="text-white font-extrabold text-sm uppercase tracking-wider mb-5 flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-[#FCBF49]" />
              Follow Us
            </h3>
            <p className="text-xs text-gray-400 mb-4">
              Follow our social channels for flash deals, student discounts, and behind-the-scenes cooking:
            </p>

            {/* Social Icons */}
            <div className="flex items-center gap-2.5">
              <a
                href={RESTAURANT_INFO.socials.facebook}
                target="_blank"
                rel="noopener noreferrer"
                aria-label="Facebook"
                className="w-10 h-10 rounded-xl bg-gray-800 text-gray-300 hover:bg-[#1877F2] hover:text-white flex items-center justify-center transition-all"
              >
                <span className="font-bold text-sm">FB</span>
              </a>
              <a
                href={RESTAURANT_INFO.socials.instagram}
                target="_blank"
                rel="noopener noreferrer"
                aria-label="Instagram"
                className="w-10 h-10 rounded-xl bg-gray-800 text-gray-300 hover:bg-[#E4405F] hover:text-white flex items-center justify-center transition-all"
              >
                <span className="font-bold text-sm">IG</span>
              </a>
              <a
                href={RESTAURANT_INFO.socials.tiktok}
                target="_blank"
                rel="noopener noreferrer"
                aria-label="TikTok"
                className="w-10 h-10 rounded-xl bg-gray-800 text-gray-300 hover:bg-black hover:text-white flex items-center justify-center transition-all"
              >
                <span className="font-bold text-sm">TT</span>
              </a>
              <a
                href={RESTAURANT_INFO.socials.youtube}
                target="_blank"
                rel="noopener noreferrer"
                aria-label="YouTube"
                className="w-10 h-10 rounded-xl bg-gray-800 text-gray-300 hover:bg-[#FF0000] hover:text-white flex items-center justify-center transition-all"
              >
                <span className="font-bold text-sm">YT</span>
              </a>
            </div>

            {/* Halal & Hygiene Pill */}
            <div className="mt-6 p-3 rounded-2xl bg-white/5 border border-white/10 flex items-center gap-3">
              <div className="w-8 h-8 rounded-lg bg-[#2A9D8F]/20 text-[#2A9D8F] flex items-center justify-center font-bold text-xs">
                ✓
              </div>
              <div className="text-xs">
                <span className="font-bold text-white block">100% Halal Certified</span>
                <span className="text-[11px] text-gray-400">Pure, fresh &amp; hygienic</span>
              </div>
            </div>
          </div>

        </div>

        {/* Copyright & Bottom bar */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-gray-500">
          <p>© 2026 {RESTAURANT_INFO.name}. All Rights Reserved.</p>
          <div className="flex items-center gap-1 text-gray-400">
            <span>Crafted with</span>
            <Heart className="w-3.5 h-3.5 text-[#D62828] fill-[#D62828]" />
            <span>for authentic Pakistani food lovers</span>
          </div>
        </div>

      </div>
    </footer>
  );
};
