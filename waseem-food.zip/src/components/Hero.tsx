import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, Flame, Sparkles, Clock, ShieldCheck, Star } from 'lucide-react';
import { RESTAURANT_INFO } from '../config/restaurant';

export const Hero: React.FC = () => {
  return (
    <section className="relative overflow-hidden bg-gradient-to-b from-[#FFF8EF] via-[#FFF3E0]/40 to-[#FFF8EF] pt-6 pb-12 sm:pb-20 lg:pt-10 lg:pb-24">
      {/* Glow Orbs */}
      <div className="absolute top-10 left-1/4 w-80 h-80 bg-[#FCBF49]/20 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute top-40 right-10 w-96 h-96 bg-[#D62828]/10 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-8 items-center">
          
          {/* Left Text Column */}
          <div className="lg:col-span-7 flex flex-col items-start text-left">
            {/* Promotional Badge */}
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#FFECEC] border border-[#D62828]/20 shadow-xs mb-5 animate-fade-in">
              <span className="w-2 h-2 rounded-full bg-[#D62828] animate-ping" />
              <Flame className="w-4 h-4 text-[#D62828] fill-[#D62828]" />
              <span className="text-xs sm:text-sm font-extrabold text-[#D62828] uppercase tracking-wider">
                Fresh • Hot • Fast Delivery
              </span>
            </div>

            {/* Main Headline */}
            <h1 className="text-4xl sm:text-5xl md:text-6xl xl:text-7xl font-black text-[#1F1F1F] font-display tracking-tight leading-[1.08]">
              Delicious Food, <br />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#D62828] via-[#E63946] to-[#F77F00]">
                Made Fresh.
              </span>
            </h1>

            {/* Subtitle */}
            <p className="mt-5 text-base sm:text-lg md:text-xl text-gray-700 max-w-xl font-normal leading-relaxed">
              {RESTAURANT_INFO.subtitle} Experience Lahore&apos;s authentic hand-crafted Biryanis, sizzling Karahis, ultra-crispy Zinger Burgers, and charcoal BBQ platters.
            </p>

            {/* Action Buttons */}
            <div className="mt-8 flex flex-wrap items-center gap-4 w-full sm:w-auto">
              <Link
                to="/menu"
                id="hero-order-now-btn"
                className="w-full sm:w-auto px-8 py-4 rounded-2xl bg-gradient-to-r from-[#D62828] via-[#E63946] to-[#F77F00] text-white font-extrabold text-base shadow-lg shadow-[#D62828]/30 hover:shadow-xl hover:shadow-[#D62828]/40 hover:-translate-y-0.5 active:translate-y-0 active:scale-98 transition-all flex items-center justify-center gap-2"
              >
                <span>Order Now</span>
                <ArrowRight className="w-5 h-5" />
              </Link>

              <Link
                to="/menu"
                id="hero-explore-menu-btn"
                className="w-full sm:w-auto px-7 py-4 rounded-2xl bg-white border-2 border-[#FCBF49] text-[#1F1F1F] hover:text-[#D62828] hover:bg-[#FFF8EF] font-bold text-base shadow-xs hover:shadow-md transition-all flex items-center justify-center gap-2"
              >
                <span>Explore Menu</span>
              </Link>
            </div>

            {/* Micro Highlights */}
            <div className="mt-10 pt-6 border-t border-[#FCBF49]/30 grid grid-cols-3 gap-4 w-full max-w-lg">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-white text-[#D62828] shadow-xs flex items-center justify-center shrink-0 border border-gray-100">
                  <Clock className="w-4 h-4" />
                </div>
                <div>
                  <span className="text-xs font-bold text-[#1F1F1F] block">30-45 Mins</span>
                  <span className="text-[11px] text-gray-500">Average Delivery</span>
                </div>
              </div>

              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-white text-[#F77F00] shadow-xs flex items-center justify-center shrink-0 border border-gray-100">
                  <Star className="w-4 h-4 fill-[#FCBF49] text-[#F77F00]" />
                </div>
                <div>
                  <span className="text-xs font-bold text-[#1F1F1F] block">4.9 / 5.0</span>
                  <span className="text-[11px] text-gray-500">12k+ Happy Foodies</span>
                </div>
              </div>

              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-white text-[#2A9D8F] shadow-xs flex items-center justify-center shrink-0 border border-gray-100">
                  <ShieldCheck className="w-4 h-4" />
                </div>
                <div>
                  <span className="text-xs font-bold text-[#1F1F1F] block">100% Halal</span>
                  <span className="text-[11px] text-gray-500">Hygienic Kitchen</span>
                </div>
              </div>
            </div>
          </div>

          {/* Right Visual Column */}
          <div className="lg:col-span-5 relative">
            <div className="relative mx-auto max-w-md lg:max-w-none">
              
              {/* Main Circular Food Presentation Canvas */}
              <div className="relative rounded-3xl overflow-hidden shadow-2xl border-4 border-white bg-gray-900 group">
                <img
                  src="https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?auto=format&fit=crop&w=1000&q=85"
                  alt="Authentic Pakistani Chicken Biryani with traditional spices"
                  className="w-full h-[380px] sm:h-[460px] object-cover object-center group-hover:scale-105 transition-transform duration-700"
                />
                
                {/* Gradient vignette */}
                <div className="absolute inset-0 bg-gradient-to-t from-black/75 via-black/20 to-transparent pointer-events-none" />

                {/* Overlaid Banner inside Image */}
                <div className="absolute bottom-5 left-5 right-5 text-white">
                  <div className="flex items-center gap-1.5 text-xs font-bold text-[#FCBF49] mb-1">
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>Today&apos;s Star Special</span>
                  </div>
                  <h3 className="text-xl sm:text-2xl font-black">
                    Shahi Chicken Biryani
                  </h3>
                  <p className="text-xs text-gray-200 mt-0.5 line-clamp-1">
                    Cooked with aged sella basmati, saffron infusion & tender chicken.
                  </p>
                  <div className="mt-3 flex items-center justify-between">
                    <span className="text-lg font-black text-white bg-[#D62828] px-3 py-1 rounded-xl">
                      Rs. 450
                    </span>
                    <Link
                      to="/product/chicken-biryani"
                      className="text-xs font-bold text-white bg-white/20 backdrop-blur-md hover:bg-white hover:text-[#D62828] px-3.5 py-1.5 rounded-xl transition-colors"
                    >
                      Quick Order
                    </Link>
                  </div>
                </div>
              </div>

              {/* Floating Floating Deal Pill Top Left */}
              <div className="absolute -top-4 -left-4 sm:-left-6 bg-white rounded-2xl p-3 shadow-xl border border-gray-100 flex items-center gap-3 animate-float">
                <div className="w-10 h-10 rounded-xl bg-[#FFF8EF] text-[#D62828] flex items-center justify-center font-black text-lg">
                  🔥
                </div>
                <div>
                  <span className="text-[10px] uppercase font-extrabold text-gray-400 block">
                    Special Offer
                  </span>
                  <span className="text-xs font-black text-[#1F1F1F]">
                    Flat 20% OFF Deals
                  </span>
                </div>
              </div>

              {/* Floating Review Pill Bottom Right */}
              <div className="absolute -bottom-5 -right-3 sm:-right-6 bg-white rounded-2xl p-3.5 shadow-xl border border-gray-100 flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-[#FCBF49]/20 text-[#F77F00] flex items-center justify-center font-black">
                  ⭐
                </div>
                <div>
                  <div className="flex items-center gap-1">
                    <span className="text-xs font-black text-[#1F1F1F]">
                      &ldquo;Best Biryani in town!&rdquo;
                    </span>
                  </div>
                  <span className="text-[10px] text-gray-500 block">
                    Verified Customer Review
                  </span>
                </div>
              </div>

            </div>
          </div>

        </div>
      </div>
    </section>
  );
};
